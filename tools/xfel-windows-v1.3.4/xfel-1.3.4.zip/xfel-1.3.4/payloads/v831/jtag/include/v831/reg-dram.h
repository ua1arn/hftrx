#ifndef __V831_REG_DRAM_H__
#define __V831_REG_DRAM_H__

#define V831_DRAM_COM_BASE			(0x04002000)
#define V831_DRAM_CTL_PHY_BASE		(0x04003000)

#endif /* __V831_REG_DRAM_H__ */
