#ifndef __T527_REG_CCU_H__
#define __T527_REG_CCU_H__

#define T527_CCU_BASE			(0x02001000)

#endif /* __T527_REG_CCU_H__ */
