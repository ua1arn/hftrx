#ifndef __XBOOT_H__
#define __XBOOT_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <types.h>
#include <io.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <endian.h>
#include <byteorder.h>

#ifdef __cplusplus
}
#endif

#endif /* __XBOOT_H__ */
