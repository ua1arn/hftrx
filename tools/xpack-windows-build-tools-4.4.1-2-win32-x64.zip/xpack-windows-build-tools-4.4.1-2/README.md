# The xPack Windows Build Tools

**The xPack Windows Build Tools** is the **xPack** version of
a standalone Windows binary distribution of
GNU make and a few of other tools required by the Eclipse Embedded CDT
(formerly GNU MCU/ARM Eclipse) project.

For more details, please read the corresponding release pages:

- <https://xpack.github.io/windows-build-tools/releases/>

Thank you for using open source software,

Liviu Ionescu
