
#include "config.h"
          

#if FOR_LINUX
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
//#include <netinet/in.h>
//#include <sys/socket.h>
#include <termios.h>
#include <termio.h>
#include <alsa/asoundlib.h>
             
             
#define Sleep(x) usleep(x*1000)
#define O_TEXT 0
#define SH_DENYWR 0
//#define O_BINARY 0

#define strncmpi strncasecmp  
#else

//#include <condefs.h>
//#include <system.hpp>
#include <winsock2.h>
#include <io.h>
#include <share.h>
//#include <process.h>
//#include <conio.h>

#endif

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <signal.h>
#include <sys/timeb.h>
       
#include "config.h"
#include "ifsk33.h"
#include "rs_code_u.h"
#include "resample.h"
#include "filters.hpp"

void DecAndAdd(double val);
void RxPutBlock(u8_t *buffer, int eot_pos);
void RxPutString(char *str);
void RxBufClear(void);
void RxPutSym(char sym);
void before_exit(void);
void Exit(int level);
void DoCmd(void);
void AlsaCloseAudioDeviceRec(void);
int AlsaOpenAudioDeviceRec(char *devname);


TIfsk33Decoder FskRx;
Decimator2Ex Dec21;
Decimator2Ex Dec22;
TUniResample Resampler;


#define HELP 1
#define SOUND_CARD_ERROR 9
#define USER_BREAK 10

#define ERROR_BREAK 100

static char *LOGTAG=(char*)"decodealsa";

u8_t    SoundBuffer[SND_REC_BUFFER_SIZE];
snd_pcm_uframes_t SoundFrames;

volatile int UserBreak=0;
volatile int ErrorBreak=0;

char HfpOutputDir[128]="./";


extern double Dec3LPCoef[DEC3_LPFIR_LENGTH];
extern double Dec2LPCoef[DEC2_LPFIR_LENGTH];
//---------------------------------------------------------------------------------------------------------


int  VerboseFlags=0;

int MaxInput=0;
int  Rezult=99;


double FskCenterFreq= 1700.0; // center freq
double FskSpeed= 50.0; 
double FskShift= 50.0; 

char *SoundDevName= NULL;
snd_pcm_t *SoundHandle=NULL;

//------------------------------------


void signal_handler(int sig)
{
#if FOR_LINUX

    switch(sig)
    {
        case SIGHUP:
            break;
        case SIGTERM:
        case SIGINT:
             UserBreak=1;
            break;
    }
#endif
}


double CenterFreq= 1500.0; // center freq
int SpeedX= 32;
int Reverse= 0;


int main(int argc, char *argv[])
{
 int paramsi;

#if FOR_LINUX
  signal(SIGCHLD, SIG_IGN);
  signal(SIGTSTP, SIG_IGN);
  signal(SIGTTOU, SIG_IGN);
  signal(SIGTTIN, SIG_IGN);
  signal(SIGHUP, signal_handler); // ������������ ������ � ������� ��� ������ ��� ������������� ������ ������������
  signal(SIGTERM, signal_handler);
  signal(SIGINT, signal_handler); 
#else
 SetConsoleCtrlHandler((PHANDLER_ROUTINE)MyHandlerRoutine,TRUE);
 //setmode(_fileno(stdin), O_BINARY);
#endif

 atexit(before_exit);

 if(argc<2) 
  {
   fprintf(stderr," Usage: \n %s Sound_device [center freq] [speedx] [reverse] \n",argv[0]);
   fprintf(stderr,"speedx = 1...64 (1.5625...100 Bd) \n");
   //ShowCardList();
   exit(HELP);
  }
 

 SoundDevName=argv[1];


 if(argc>2)
  {
   int cfreq=atoi(argv[2]);
   FskCenterFreq= (double)cfreq;
  }



 if(argc>2)
  {
   CenterFreq=atof(argv[2]);
  }


 if(argc>3)
  {
   SpeedX=atoi(argv[3]);
  }
 double SpeedHz= 1.5625*(double)SpeedX;

 if(argc>4)
  {
   Reverse=atoi(argv[4]);
  }


 
 printf("\nSound device: %s \n",SoundDevName);
 printf("\nCenter freq: %.2lf \n",CenterFreq);
 printf("\nSpeed: %lf \n",SpeedHz);
 printf("\nReverse: %d \n",Reverse);

 Rezult=99;

  DoCmd();

  Exit(Rezult);

 return Rezult;
}
//---------------------------------------------------------------------------
void DoCmd(void)
{
 FskRx.Init(SpeedX,CenterFreq,Reverse);
 //FskRx.SetCallback(&OnMessageHandler);

 Dec21.Set(DEC3_LPFIR_LENGTH,Dec3LPCoef);
 Dec21.Reset();
 Dec22.Set(DEC2_LPFIR_LENGTH,Dec2LPCoef);
 Dec22.Reset();

 Resampler.Init((double)NOMINAL_SAMPLING_RATE*0.5,NOMINAL_EQ_RATE*2.0,&DecAndAdd);


 int rez=AlsaOpenAudioDeviceRec(SoundDevName);
 if(rez) 
  {
   fprintf(stderr,"Sound device open error! (%d) \n",rez);
   Rezult=SOUND_CARD_ERROR;
   return;
  }


 static unsigned int decim_k=0;

 while ((!UserBreak) && (!ErrorBreak))
  {
    rez = snd_pcm_readi(SoundHandle, SoundBuffer, SoundFrames);
    if (rez == -EPIPE) {
      /* EPIPE means overrun */
      fprintf(stderr, "overrun occurred\n");
      snd_pcm_prepare(SoundHandle);
    } 
    else if (rez < 0) {
      fprintf(stderr,"error from read: %s\n",snd_strerror(rez));
      ErrorBreak=1;
      break;
    }
    else if (rez != (int)SoundFrames) {
      fprintf(stderr, "short read, read %d frames\n", rez);
    }


    s16_t *p= (s16_t*)SoundBuffer;
    for(int i=0;i<rez;i++)
     {
      double v1=Dec21.Filter(*(p++));
      if((decim_k++)&1)
       {
        Resampler.AddSample(v1);
       }
     }
   }          

  
 if(UserBreak) Rezult=USER_BREAK;
 else Rezult=ERROR_BREAK;
}
//---------------------------------------------------------------------------
void Exit(int level)
{
 before_exit();
 exit(level);
}
//----------------------------------------------------------------------------------------------------------
void before_exit(void)
{
#if FOR_LINUX
 AlsaCloseAudioDeviceRec();
#endif
}
//-----------------------------------------------------------------------------------------------------------
int AlsaOpenAudioDeviceRec(char *devname)
// ���������� 0 ��� ������
{
 AlsaCloseAudioDeviceRec(); // �������, ���� ������

 int rc;
 snd_pcm_hw_params_t *params;
 unsigned int val;
 snd_pcm_uframes_t frames;


 /* Open PCM device for recording (capture). */
 rc = snd_pcm_open(&SoundHandle, devname , SND_PCM_STREAM_CAPTURE, 0);
 if (rc < 0)
   {
    LOGE("Unable to open pcm device: %s ",snd_strerror(rc));
    SoundHandle=NULL;
    return -1;
 }


 /* Allocate a hardware parameters object. */
 snd_pcm_hw_params_alloca(&params);


 /* Fill it in with default values. */
 snd_pcm_hw_params_any(SoundHandle, params);


 /* Set the desired hardware parameters. */


 /* Interleaved mode */
 int err=snd_pcm_hw_params_set_access(SoundHandle, params,SND_PCM_ACCESS_RW_INTERLEAVED);
 if (err < 0)
  {
   LOGE("Access type not available");                      
   AlsaCloseAudioDeviceRec();
   return -2;
  }


 /* Signed 16-bit little-endian format */
 err=snd_pcm_hw_params_set_format(SoundHandle, params,SND_PCM_FORMAT_S16_LE);                                 
 if (err < 0)
  {
   LOGE("PCM format not available");        
   AlsaCloseAudioDeviceRec();
   return -3;
  }

 /* mono */
 err=snd_pcm_hw_params_set_channels(SoundHandle, params, 1);                                 
 if (err < 0)
  {
   LOGE("Channel num not available");                      
   AlsaCloseAudioDeviceRec();
   return -4;
  }

 /* 44100 samples/second sampling rate */
 val = NOMINAL_SAMPLING_RATE;                                                     
 err=snd_pcm_hw_params_set_rate_near(SoundHandle, params,&val, 0);
 if (err < 0)
  {
   LOGE("Rate not available");                      
   AlsaCloseAudioDeviceRec();
   return -5;
  }

  if ((float)val * 1.02 < (float)NOMINAL_SAMPLING_RATE  || (float)val * 0.98 > (float)NOMINAL_SAMPLING_RATE)
    {
     LOGE("Rate is not accurate (requested = %d , got = %d )",NOMINAL_SAMPLING_RATE, val);
     AlsaCloseAudioDeviceRec();
     return -6;
    }

 /* Set period size to n frames. */
 frames = (SND_REC_BUFFER_SIZE)/2;
 snd_pcm_hw_params_set_period_size_near(SoundHandle,params, &frames, 0);

 snd_pcm_uframes_t buffers = SND_REC_BUFFER_SIZE*2;
 snd_pcm_hw_params_set_buffer_size_near(SoundHandle,params, &buffers);


 /* Write the parameters to the driver */
 rc = snd_pcm_hw_params(SoundHandle, params);
 if (rc < 0) 
   {
    LOGE("unable to set hw parameters: %s",snd_strerror(rc));
    AlsaCloseAudioDeviceRec();
    return -7;
   }


 /* Use a buffer large enough to hold one period */
 snd_pcm_hw_params_get_period_size(params,&frames, 0);
 LOGI("Recording period size: %ld frames",(long)frames);                                      

 snd_pcm_hw_params_get_buffer_size(params,&buffers);
 LOGI("Recording buffer size: %lu frames \n",(unsigned long)buffers);


 if((frames*2)>SND_REC_BUFFER_SIZE)
  {
   LOGE("Unsufficient buffer size!");
   AlsaCloseAudioDeviceRec();
   return -8;
  }

 SoundFrames=frames;

 return 0;
}
//--------------------------------------------------
void AlsaCloseAudioDeviceRec(void)
 {
  if(SoundHandle!=NULL)
   {
    snd_pcm_drain(SoundHandle);
    snd_pcm_close(SoundHandle);
    SoundHandle=NULL;
   }
 }
//--------------------------------------------------
void RxPutSym(char sym)
{
 char sym1=sym;
 if(((sym&255)<' ') && (sym!='\r') && (sym!='\n')) sym1='.';
 putchar(sym1);
}
//---------------------------------------------------------------------------
void RxBufClear(void)
{
 // ���������� � ������ ����� ��������� 
 RxPutSym('\r');
 RxPutSym('\n');
 fflush(stdout);
}
//-----------------------------------------------------------------------------
void RxPutString(char *str)
{
 for(;*str;str++) RxPutSym(*str);
 fflush(stdout);
}
//-----------------------------------------------------------------------------
void RxPutBlock(u8_t *buffer, int eot_pos)
{
 int len=7;
 if(eot_pos>=0) len=eot_pos;
 for(int i=0;i<len;i++)
  {
   RxPutSym(buffer[i]);
  }
 fflush(stdout);
}
//-----------------------------------------------------------------------------
void DecAndAdd(double val)
// ���������� �� ��� � ������� �� ���������� ���������
{
 static unsigned int k=0;
 double v2=Dec22.Filter(val);
 k++;
 if((k&1)==0)
  {
   FskRx.RxSample((float)v2);
  }
}
//------------------------------------------------------
