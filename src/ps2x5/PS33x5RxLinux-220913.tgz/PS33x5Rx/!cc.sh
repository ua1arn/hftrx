#!/bin/sh
g++ decodealsa.cpp ifsk33.cpp fft.cpp resample.cpp rs_code_u.cpp filters.cpp crc16.cpp -lasound -o decodealsa
