
#include "config.h"
          
//#include <condefs.h>
//#include <system.hpp>
#include <windows.h>
#include <mmsystem.h>
#include <io.h>
#include <share.h>
//#include <process.h>
//#include <conio.h>

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <signal.h>
#include <sys/timeb.h>


#include "config.h"
#include "ifsk33.h"
#include "rs_code_u.h"
#include "wavework.h"
#include "resample.h"
#include "filters.hpp"



void DecAndAdd(double val);
void RxPutBlock(u8_t *buffer, int eot_pos);
void RxPutString(char *str);
void RxBufClear(void);
                  

TIfsk33Decoder FskRx;
Decimator2Ex Dec21;
Decimator2Ex Dec22;
TUniResample Resampler;

          
extern double Dec3LPCoef[DEC3_LPFIR_LENGTH];
extern double Dec2LPCoef[DEC2_LPFIR_LENGTH];
        

#define HELP 1
#define SOUND_CARD_ERROR 9
#define USER_BREAK 10

#define ERROR_BREAK 100

void before_exit(void);
void Exit(int level);
void DoCmd(void);
BOOL MyHandlerRoutine(DWORD tsign);
void ShowCardList(void);
int  CardInit(void);
void CALLBACK WaveCallback(HWAVEIN hwi,UINT uMsg,DWORD dwInstance, DWORD dwParam1, DWORD dwParam2);
void BufferFillHandler(void);
void BufferHandler(s16_t *buffer);
void CloseSoundCard(void);
void DecAndAdd(double val);

//---------------------------------------------------------------------------
#define WBUFF_LEN 12000 
#define WBUFF_NUM 8  /* number of buffer - power of 2 */
short   *w_buffer[WBUFF_NUM];
WAVEHDR w_header[WBUFF_NUM];

short Wbuff0[WBUFF_LEN];
short Wbuff1[WBUFF_LEN];
short Wbuff2[WBUFF_LEN];
short Wbuff3[WBUFF_LEN];
short Wbuff4[WBUFF_LEN];
short Wbuff5[WBUFF_LEN];
short Wbuff6[WBUFF_LEN];
short Wbuff7[WBUFF_LEN];


char HfpOutputDir[128]="./";

HWAVEIN SoundHandle=NULL;
int FilledBuffs=0; // ���������� ����������� �������
int AddedBuffs=0;  // ���������� �������������� ��� ���������� �������
int WaveHead=0;    // ����� ������, � ������� ���� ������
int WaveTail=0;    // ����� ������, �� �������� ���� ������


volatile int UserBreak=0;
volatile int ErrorBreak=0;
volatile int SoundClosingFlag=0;
//---------------------------------------------------------------------------------------------------------



u32_t SoundDevNumber=WAVE_MAPPER;


int  VerboseFlags=0;

int MaxInput=0;
int  Rezult=99;



double CenterFreq= 1500.0; // center freq
int SpeedX= 32;
int Reverse= 0;

//------------------------------------


int main(int argc, char *argv[])
{
 int paramsi;

#if FOR_LINUX
  signal(SIGCHLD, SIG_IGN);
  signal(SIGTSTP, SIG_IGN);
  signal(SIGTTOU, SIG_IGN);
  signal(SIGTTIN, SIG_IGN);
  signal(SIGHUP, SIG_IGN); // ������������ ������ � ������� ��� ������ ��� ������������� ������ ������������
  signal(SIGTERM, SIG_IGN);
  signal(SIGINT, signal_handler); 
#else
 SetConsoleCtrlHandler((PHANDLER_ROUTINE)MyHandlerRoutine,TRUE);
 //setmode(_fileno(stdin), O_BINARY);
#endif

 atexit(before_exit);

 if(argc<2) 
  {
   fprintf(stderr," Usage: \n %s Soundcard_Number [center freq] [speedx] [reverse] \n",argv[0]);
   fprintf(stderr," Soundcard_Number<0 means \"Default soundcard\" \n");
   ShowCardList();
   exit(HELP);
  }
 

 int sdev=atoi(argv[1]);
 if(sdev>=0) SoundDevNumber=sdev;

  
 if(argc>2)
  {
   CenterFreq=atof(argv[2]);
  }


 if(argc>3)
  {
   SpeedX=atoi(argv[3]);
  }
 double SpeedHz= 1.5625*(double)SpeedX;

 if(argc>4)
  {
   Reverse=atoi(argv[4]);
  }


 printf("\nSoundcard: %d \n",sdev);
 printf("\nCenter freq: %.2lf \n",CenterFreq);
 printf("\nSpeed: %lf \n",SpeedHz);
 printf("\nReverse: %d \n",Reverse);


 Rezult=99;

 DoCmd();

 Exit(Rezult);

 return Rezult;
}
//---------------------------------------------------------------------------
void ShowCardList(void)
{
 printf("\n\n Soundcard list: \n");
 WAVEINCAPS InCaps;
 int indevnum=waveInGetNumDevs();
 for(int i=0; i<indevnum; i++)
   {
    MMRESULT mmrez;
    mmrez=waveInGetDevCaps(i,&InCaps,sizeof(InCaps));
    if(mmrez==MMSYSERR_NOERROR)
     {
      CharToOem(InCaps.szPname,InCaps.szPname);
      printf(" %3d - %s \n",i,InCaps.szPname);
     }
   }

}

//---------------------------------------------------------------------------
void DoCmd(void)
{

 FskRx.Init(SpeedX,CenterFreq,Reverse);
 //FskRx.SetCallback(&OnMessageHandler);


 Dec21.Set(DEC3_LPFIR_LENGTH,Dec3LPCoef);
 Dec21.Reset();
 Dec22.Set(DEC2_LPFIR_LENGTH,Dec2LPCoef);
 Dec22.Reset();

 Resampler.Init((double)NOMINAL_SAMPLING_RATE*0.5,NOMINAL_EQ_RATE*2.0,&DecAndAdd);


 if(CardInit()!=0)
  {
   Rezult=SOUND_CARD_ERROR;
   return;
  }

 while ((!UserBreak) && (!ErrorBreak))
  {
   if(FilledBuffs>0) BufferFillHandler();
   else Sleep(60);
  }          
  
 if(UserBreak) Rezult=USER_BREAK;
 else Rezult=ERROR_BREAK;
}
//---------------------------------------------------------------------------
void Exit(int level)
{
 before_exit();
 exit(level);
}
//----------------------------------------------------------------------------------------------------------
void before_exit(void)
{
 CloseSoundCard();
}

//-----------------------------------------------------------------------------------------------------------
#pragma argsused
BOOL MyHandlerRoutine(DWORD tsign)
{
 UserBreak=1;
 return TRUE;
}
//-------------------------------------------------------------------------------------------------------------
int  CardInit(void)
 {
  WAVEFORMATEX WvFormat;
  int inpdevnum;
  MMRESULT rez;

  int i;
  char str[1000];

  // ������� �������� � ���������:
  AddedBuffs=0;
  FilledBuffs=0;
  WaveHead=0;
  WaveTail=0;


  // ��������� ������:

  WvFormat.wFormatTag=WAVE_FORMAT_PCM;
  WvFormat.nSamplesPerSec=NOMINAL_SAMPLING_RATE;
  WvFormat.nChannels=1;
  WvFormat.nAvgBytesPerSec=NOMINAL_SAMPLING_RATE*2;
  WvFormat.nBlockAlign=2;
   
  WvFormat.wBitsPerSample=16;
  WvFormat.cbSize=0;

  rez=waveInOpen(&SoundHandle, SoundDevNumber, &WvFormat, (DWORD)WaveCallback, 0, CALLBACK_FUNCTION);


  if(rez!=MMSYSERR_NOERROR) 
   {
    inpdevnum=waveInGetNumDevs();
    if(inpdevnum<1)
     {
      fprintf(stderr,"No sound input device! \n");
      return -1; 
     }
   }


  switch(rez)
      {
      case MMSYSERR_NOERROR:
          break;
      case MMSYSERR_ALLOCATED:
          fprintf(stderr,"  Specified resource is already allocated \n");
          break;
      case MMSYSERR_BADDEVICEID:
          fprintf(stderr,"  Specified device identifier is out of range \n");
          break;
      case MMSYSERR_NODRIVER:
          fprintf(stderr,"  No device driver is present \n");
          break;
      case MMSYSERR_NOMEM:
          fprintf(stderr,"  Unable to allocate or lock memory \n");
          break;
      case WAVERR_BADFORMAT:
          fprintf(stderr,"  Attempted to open with an unsupported waveform-audio format \n");
          break;
      default:
          fprintf(stderr," Unrecognized ERROR \n");
      }

  if(rez!=MMSYSERR_NOERROR)
   {
       return -2;
   }
 //===========

  w_buffer[0]=Wbuff0;
  w_buffer[1]=Wbuff1;
  w_buffer[2]=Wbuff2;
  w_buffer[3]=Wbuff3;
  w_buffer[4]=Wbuff4;
  w_buffer[5]=Wbuff5;
  w_buffer[6]=Wbuff6;
  w_buffer[7]=Wbuff7;


  for(i=0;i<WBUFF_NUM;i++)
   {
    w_header[i].lpData= (char*)(w_buffer[i]);
    w_header[i].dwBufferLength= WBUFF_LEN*2; // � ������
    w_header[i].dwFlags=0;
    rez=waveInPrepareHeader(SoundHandle,&w_header[i],sizeof(w_header[i]));
    if(rez!=MMSYSERR_NOERROR)
     {
      waveInClose(SoundHandle);
      fprintf(stderr,"  Error in Prepare Header! \n");
      SoundHandle=NULL;
      return -3;
     }

    rez=waveInAddBuffer(SoundHandle,&w_header[i],sizeof(w_header[i]));
    if(rez!=MMSYSERR_NOERROR)
     {
      waveInClose(SoundHandle);
      fprintf(stderr,"  Error in AddBuffer! \n");
      SoundHandle=NULL;
      return -4;
     }

     WaveHead++;
     WaveHead&=(WBUFF_NUM-1);
     AddedBuffs++;
    }

  rez=waveInStart(SoundHandle);
  if(rez!=MMSYSERR_NOERROR)
   {
    waveInClose(SoundHandle);
    fprintf(stderr,"  Error in Start! \n");
    SoundHandle=NULL;
    return -5; 
   }

  SoundClosingFlag=0;
  return 0;
 }
//--------------------------------------------------------
void CALLBACK WaveCallback(HWAVEIN hwi,UINT uMsg,DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
 {
     if(uMsg==WIM_DATA)
     {
       FilledBuffs++;
       AddedBuffs--;
     }
 }
//--------------------------------------------------------
void BufferFillHandler(void)
// ���������� ������� "����� ��������"
{
     char str[200];
     MMRESULT rez;
     static int in_use=0;

     if(in_use) return;
     if(SoundClosingFlag) return;
     if(SoundHandle==NULL) return;

     in_use=1;

     while(FilledBuffs)
       {
        FilledBuffs--;
        BufferHandler(w_buffer[WaveTail]);
        WaveTail++;
        WaveTail &= (WBUFF_NUM-1);

        if(!SoundClosingFlag) // ���� �� ��������� ��������� ...
        {
         // ���� ��������� �����
         AddedBuffs++;
         w_header[WaveHead].lpData= (char*)(w_buffer[WaveHead]);
         w_header[WaveHead].dwBufferLength= WBUFF_LEN*2; // � ������
         w_header[WaveHead].dwFlags &= ~WHDR_DONE; /* ��� ���������� ��� ������, �� ������� � ��� ������.
                                                              Clear the WHDR_DONE bit (which the driver set last time that
                                                              this WAVEHDR was sent via waveOutWrite and was played). Some
                                                              drivers need this to be cleared */


         rez=waveInAddBuffer(SoundHandle,&w_header[WaveHead],sizeof(w_header[WaveHead]));
         if(rez!=MMSYSERR_NOERROR)
          {
           waveInClose(SoundHandle);
           fprintf(stderr,"  Error in AddBuffer! \n");
           SoundHandle=NULL;
           ErrorBreak=1;
          }
         WaveHead++;
         WaveHead &= (WBUFF_NUM-1);
         // RxForm->UpdateControlState();
        }
       }
   in_use=0;
 }
//--------------------------------------------------------
void CloseSoundCard(void)
{
 int i,tmp;
 HWAVEIN handle;

 SoundClosingFlag=1;

 if(SoundHandle!=NULL)
  {
   handle=SoundHandle;
   SoundHandle=NULL;
   waveInStop(handle);
   waveInReset(handle);
   tmp=1;
   while(tmp) {tmp=AddedBuffs;Sleep(10);} // ���� ������������ �������
   for(i=0;i<WBUFF_NUM;i++)
    {
     waveInUnprepareHeader(handle,&w_header[i],sizeof(w_header[i]));
    }
   waveInClose(handle);
  }

 
 AddedBuffs=0;
 FilledBuffs=0;
 WaveHead=0;
 WaveTail=0;
}
//---------------------------------------------------------------------------
void BufferHandler(s16_t *buffer)
{
 static unsigned int decim_k=0;
 for(int i=0;i<WBUFF_LEN;i++)
  {
   double v1=Dec21.Filter(buffer[i]);
   if((decim_k++)&1)
    {
     Resampler.AddSample(v1);
    }
  }
}
//--------------------------------------------------
void DecAndAdd(double val)
// ���������� �� ��� � ������� �� ���������� ���������
{
 static unsigned int k=0;
 double v2=Dec22.Filter(val);
 k++;
 if((k&1)==0)
  {
   FskRx.RxSample((float)v2);
  }
}
//------------------------------------------------------

void RxPutSym(char sym)
{
 char sym1=sym;
 if(((sym&255)<' ') && (sym!='\r') && (sym!='\n')) sym1='.';
 putchar(sym1);
}
//---------------------------------------------------------------------------
void RxBufClear(void)
{
 // ���������� � ������ ����� ��������� 
 RxPutSym('\r');
 RxPutSym('\n');
 fflush(stdout);
}
//-----------------------------------------------------------------------------
void RxPutString(char *str)
{
 for(;*str;str++) RxPutSym(*str);
 fflush(stdout);
}
//-----------------------------------------------------------------------------
void RxPutBlock(u8_t *buffer, int eot_pos)
{
 int len=7;
 if(eot_pos>=0) len=eot_pos;
 for(int i=0;i<len;i++)
  {
   RxPutSym(buffer[i]);
  }
 fflush(stdout);
}
//-----------------------------------------------------------------------------

