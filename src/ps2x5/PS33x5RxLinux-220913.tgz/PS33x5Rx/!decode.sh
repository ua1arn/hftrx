#!/bin/sh
./decodealsa plughw:1,0 1500 32

