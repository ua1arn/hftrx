#ifndef _TYPEDEFS_1234567C_INCLUDED
#define _TYPEDEFS_1234567C_INCLUDED
//----------------------------------------------------------------

#include <stdio.h>
#include <stdint.h>
      
#define FOR_LINUX 1
#define FOR_ANDROID 0
    
#define DEBUG_PRINT 0

#define FSK2_5_CRC_MASK 0x357A 
#define FSK2_5_EOT_CRC_MASK 0x53A7 
  
#define NOMINAL_SAMPLING_RATE 44100
#define NOMINAL_EQ_RATE 12800.0  
#define FINE_SINUS_TABLE_LEN  32768  
#define SINUS_AMPLITUDE 32000        

#define SND_REC_BUFFER_SIZE 8192 // ������ ������ ������ (�������) � ������  - 4096 ������� * 2
        
#define EOT_SYM 4

#define ERR_PRINT_FORMAT "{ER=%.1lf%%}"

                  
/* Definition of Types *
 ***********************/

typedef uint8_t  u8_t;
typedef uint8_t  BYTE;
typedef uint16_t u16_t;
typedef uint32_t u32_t;
typedef uint32_t DWORD;

typedef uint64_t Int64;

typedef int8_t  s8_t;
typedef int16_t s16_t;
typedef int32_t s32_t;
typedef uint64_t u64_t;
typedef int64_t  s64_t;


#define LOGI(...) do{fprintf(stderr,"\n***I: %s: ",LOGTAG);fprintf(stderr,__VA_ARGS__);fprintf(stderr,"\n");}while(0)
#define LOGW(...) do{fprintf(stderr,"\n***W: %s: ",LOGTAG);fprintf(stderr,__VA_ARGS__);fprintf(stderr,"\n");}while(0)
#define LOGE(...) do{fprintf(stderr,"\n***E: %s: ",LOGTAG);fprintf(stderr,__VA_ARGS__);fprintf(stderr,"\n");}while(0)
#define LOGD(...) do{fprintf(stderr,"\n***D: %s: ",LOGTAG);fprintf(stderr,__VA_ARGS__);fprintf(stderr,"\n");}while(0)

#endif


