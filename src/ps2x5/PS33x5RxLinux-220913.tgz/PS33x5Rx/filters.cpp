// �������� �������

#include <math.h>
#include "config.h"
#include "filters.hpp"

//extern double FirPass_1250_2650[];


//  Design method: Parks-McClellan method
//  Number of taps  =  45
//  Number of bands =  2
//  Band     Lower       Upper       Value      Weight
//            edge        edge
//   1         0.0       .018         1.0         1
//   2         .25        .5        .00007       100
double Dec2LPCoef[DEC2_LPFIR_LENGTH ] = {
  0.00041063658,
  0.00040020444,
  -0.0014690721,
  -0.0046244896,
  -0.0048873265,
  0.00057075169,
   0.0064849067,
   0.0034999371,
  -0.0072838126,
   -0.010484073,
   0.0032609865,
    0.017545124,
   0.0073308048,
    -0.02042501,
   -0.024496589,
    0.013398095,
    0.045762697,
    0.010940839,
   -0.066633815,
   -0.069373038,
    0.081944411,
     0.30510648,
     0.41246774,
     0.30510648,
    0.081944411,
   -0.069373038,
   -0.066633815,
    0.010940839,
    0.045762697,
    0.013398095,
   -0.024496589,
    -0.02042501,
   0.0073308048,
    0.017545124,
   0.0032609865,
   -0.010484073,
  -0.0072838126,
   0.0034999371,
   0.0064849067,
  0.00057075169,
  -0.0048873265,
  -0.0046244896,
  -0.0014690721,
  0.00040020444,
  0.00041063658
};



// ��������� �� 2
//--------------------------------------
Decimator2::Decimator2()
  {
   int i;

   cur_in=0;
   counter=0;
   s=0.0;
   for(i=0;i<DEC2_LPFIR_LENGTH;i++) buffer[i]=0.0;
  }
//--------------------------------------
void Decimator2::Reset(void)
  {
   int i;

   cur_in=0;
   counter=0;
   s=0.0;
   for(i=0;i<DEC2_LPFIR_LENGTH;i++) buffer[i]=0.0;
  }
//--------------------------------------
Decimator2::~Decimator2()
  {
   //
  }
//----------------------------------------
double   Decimator2::Filter(double input)
{
 int i, j;

 i = cur_in++;
 if (cur_in == DEC2_LPFIR_LENGTH) cur_in = 0;
 buffer[i] = input;

 if(counter&1)
 {
  // ����� ������ ������ ������
  // ����� ������ ���������� ���������� ���������
  s = 0.0;
  for (j = 0; j < DEC2_LPFIR_LENGTH;) {
     s += buffer[i--] * Dec2LPCoef[j++];
     if (i < 0) i += DEC2_LPFIR_LENGTH;
  }
 }

 counter++;
 return s;
}
//======================================================

Decimator2Ex::Decimator2Ex()
  {
   Inited=0;
   Buffer=NULL;
  }
//--------------------------------------
void Decimator2Ex::Reset(void)
  {
   int i;
   if(!Inited) return;

   cur_in=0;
   counter=0;
   s=0.0;
   for(i=0;i<FirLen;i++) Buffer[i]=0.0;
  }
//--------------------------------------
void   Decimator2Ex::Set(int fir_len, double *fir_coeff)
{
 if(Buffer!=NULL)
     {
      delete[] Buffer;
      Buffer=NULL;
     }
 Buffer = new double[fir_len+1];
 if(Buffer!=NULL) Inited=1;
 FirLen=fir_len;
 FirCoeff=fir_coeff;
 Reset();
}
//---------------------------------------
Decimator2Ex::~Decimator2Ex()
  {
      if(Buffer!=NULL)
          {
           delete[] Buffer;
           Buffer=NULL;
          }
  }
//----------------------------------------
double   Decimator2Ex::Filter(double input)
{
 int i, j;

 i = cur_in++;
 if (cur_in == FirLen) cur_in = 0;
 Buffer[i] = input;

 if(counter&1)
 {
  // ����� ������ ������ ������
  // ����� ������ ���������� ���������� ���������
  s = 0.0;
  for (j = 0; j < FirLen;) {
     s += Buffer[i--] * FirCoeff[j++];
     if (i < 0) i += FirLen;
  }
 }

 counter++;
 return s;
}
//======================================================


//  Design method: Parks-McClellan method
//  Number of taps  =  27
//  Number of bands =  2
//  Band     Lower       Upper       Value      Weight
//            edge        edge
//   1         0.0       .017         1.0         1
//   2         .166666    .5        .00002       10
double Dec3LPCoef[DEC3_LPFIR_LENGTH ] = {
 -0.00028892587,
  -0.0012431135,
  -0.0033184787,
  -0.0065777314,
   -0.010172455,
   -0.011982908,
  -0.0087991708,
   0.0027573615,
    0.024743232,
     0.05640933,
     0.09349033,
     0.12882953,
     0.15434156,
     0.16367159,
     0.15434156,
     0.12882953,
     0.09349033,
     0.05640933,
    0.024743232,
   0.0027573615,
  -0.0087991708,
   -0.011982908,
   -0.010172455,
  -0.0065777314,
  -0.0033184787,
  -0.0012431135,
 -0.00028892587
};


Decimator3::Decimator3()
  {
   int i;

   cur_in=0;
   counter=0;
   s=0.0;
   for(i=0;i<DEC3_LPFIR_LENGTH;i++) buffer[i]=0.0;
  }
//--------------------------------------
Decimator3::~Decimator3()
  {
   //
  }
//----------------------------------------
void Decimator3::Reset(void)
  {
   int i;

   cur_in=0;
   counter=0;
   s=0.0;
   for(i=0;i<DEC3_LPFIR_LENGTH;i++) buffer[i]=0.0;
  }
//--------------------------------------
double   Decimator3::Filter(double input)
{
 int i, j;

      i = cur_in++;
      if (cur_in == DEC3_LPFIR_LENGTH) cur_in = 0;
      buffer[i] = input;

      counter++;
      if(counter>=3)
      {
       // ����� ������ ������ ������
       // ����� ������ ���������� ���������� ���������
       s = 0.0;
       for (j = 0; j < DEC3_LPFIR_LENGTH;) {
          s += buffer[i--] * Dec3LPCoef[j++];
          if (i < 0) i += DEC3_LPFIR_LENGTH;
       }
       counter=0;
      }

      return s;
}
//-------------------------------------------------
// FIR-������

FirFilter::FirFilter()
  {
   Length=0;
   cur_in=0;
   Buffer=NULL;
   Koeff=NULL;
  }
//--------------------------------------
FirFilter::~FirFilter()
  {
   if(Buffer!=NULL)
       {
        delete[] Buffer;
        Buffer=NULL;
       }
  }
//----------------------------------------
void   FirFilter::Set(int firlen, double *firkoeff)
// ��������� ���������� �������
 {
  int i;

  Length=0;
  Koeff=firkoeff;
  if(Buffer!=NULL)
      {
       delete[] Buffer;
       Buffer=NULL;
      }
  Buffer = new double[firlen+1];
  if(Buffer!= NULL)
    {
     for(i=0;i<firlen;i++) Buffer[i]=0.0;
     cur_in=0;
     Length=firlen;
    }
 }
//------------------------------------------
double   FirFilter::Filter(double input)
{
 int i, j;
 double s;

 if(!Length) return 0.0; // �� ������������������

      i = cur_in++;
      if (cur_in >= Length) cur_in = 0;
      Buffer[i] = input;

      s = 0.0;
      for (j = 0; j < Length;) {
          s += Buffer[i--] * Koeff[j++];
          if (i < 0) i += Length;
      }
      return s;
}
//---------------------------------------------------------
// IIR-������
//----------
IirFilter::IirFilter()
  {
   int i;
   Gain= -1.0;
   for(i=0;i<(SECTION*2);i++) buffer[i]=0.0;
   m1 = buffer; m2 = m1 + SECTION;
  }
//--------------------------------------
IirFilter::~IirFilter()
  {
   //
  }
//----------------------------------------
void   IirFilter::Set(double *denum, double *num, double fgain)
{
 int i;

    Gain= -1.0;
    for(i=0;i<(SECTION*2);i++) buffer[i]=0.0;
    m1 = buffer; m2 = m1 + SECTION;
    Denumerator=denum;
    Numerator=num;
    Gain=fgain;
}
//----------------------------------------
double   IirFilter::Filter(double input)
   {
    int i;
    double *a, *b, s0, s1;

    if(Gain <0.0) return 0.0; // ��������� �� �����������
    a = Denumerator; b = Numerator;  s0 = Gain * input;

    for (i = 0; i < SECTION; i++) {
          s1 = (s0 * b[0] + m1[i]) / a[0];
          m1[i] = m2[i] + s0 * b[1] - s1 * a[1];
          m2[i] = s0 * b[2] - s1 * a[2];
          s0 = s1; a += 3; b += 3;
    }
  return s1;
}
//=====================================================
TReqtFilter::TReqtFilter()
 {
  Buffer=NULL;
 }
//------------------------------
TReqtFilter::~TReqtFilter()
 {
  if(Buffer!=NULL) delete[] Buffer;
  Buffer=NULL;
 }
//------------------------------
void   TReqtFilter::Set(int firlen)
 {
  double *tmp;
  int i;

  tmp=Buffer;
  Buffer=NULL;
  if(tmp!=NULL) delete[] tmp;

  Sum=0.0;
  Index=0;
  Length=firlen;
  Buffer=new double[Length];

  if(Buffer==NULL) return; // ���������� � ���������� ������

  for(i=0;i<Length;i++) Buffer[i]=0.0;
 }
//------------------------------
void TReqtFilter::ReSet(void)
 {
  int i;

  if(Buffer==NULL) return; // ���������� � ���������� ������
  Sum=0.0;
  Index=0;
  for(i=0;i<Length;i++) Buffer[i]=0.0;
 }
//------------------------------
double   TReqtFilter::Filter(double input)
 {
  if(Buffer==NULL) return 0.0; // �� ������������������

  Sum-= Buffer[Index];
  Sum+= input;
  Buffer[Index++]=input;

  if(Index>=Length) Index=0;

  return Sum/Length;
 }
//--------------------------------------------------

