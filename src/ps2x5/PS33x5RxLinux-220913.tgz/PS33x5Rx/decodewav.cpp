
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <fcntl.h>
#include <limits.h>

#include "config.h"
#include "ifsk33.h"
#include "rs_code_u.h"
#include "wavework.h"
#include "resample.h"
#include "filters.hpp"



void DecAndAdd(double val);
                  
TWaveRead WaveReader;
TIfsk33Decoder FskRx;
Decimator2Ex Dec21;
Decimator2Ex Dec22;
TUniResample Resampler;

          
extern double Dec3LPCoef[DEC3_LPFIR_LENGTH];
extern double Dec2LPCoef[DEC2_LPFIR_LENGTH];
char Str128[128];


//void OnMessageHandler(unsigned char *buffer, int error_counter, int av_offset);

int main(int argc, char* argv[])
{
 char *filename="test.wav";

 if(argc>1)
  {
   filename= argv[1];
  }



 double CenterFreq= 1500.0; // center freq
 if(argc>2)
  {
   CenterFreq=atof(argv[2]);
  }


 int SpeedX= 32; 
 if(argc>3)
  {
   SpeedX=atoi(argv[3]);
  }
 double SpeedHz= 1.5625*(double)SpeedX;

 int Reverse= 0; 
 if(argc>4)
  {
   Reverse=atoi(argv[4]);
  }


 printf("\nFile: %s \n",filename);
 printf("\nCenter freq: %.2lf \n",CenterFreq);
 printf("\nSpeed: %lf \n",SpeedHz);
 printf("\nReverse: %d \n",Reverse);



 FskRx.Init(SpeedX,CenterFreq,Reverse);
 //FskRx.SetCallback(&OnMessageHandler);


 Dec21.Set(DEC3_LPFIR_LENGTH,Dec3LPCoef);
 Dec21.Reset();
 Dec22.Set(DEC2_LPFIR_LENGTH,Dec2LPCoef);
 Dec22.Reset();

 Resampler.Init((double)NOMINAL_SAMPLING_RATE*0.5,NOMINAL_EQ_RATE*2.0,&DecAndAdd);


 int rez=WaveReader.OpenFile(filename);

 if(rez!=0)
  {
   printf("\n Wave file [%s] open error! (%d) \n",filename,rez);
   exit(1);
  }

 static unsigned int decim_k=0;
 while(WaveReader.WaveDataSize>0)
  {
   s16_t sample=WaveReader.Read();
   double v1=Dec21.Filter(sample);
   if((decim_k++)&1)
     {
      Resampler.AddSample(v1);
     }
  }

 // flush 
 for(int i=0;i<12000;i++) FskRx.RxSample(0.0F);

 WaveReader.CloseFile();


 return 0;
}
                         
//--------------------------------------------------
void DecAndAdd(double val)
// ���������� �� ��� � ������� �� ���������� ���������
{
 static unsigned int k=0;
 double v2=Dec22.Filter(val);
 k++;
 if((k&1)==0)
  {
   FskRx.RxSample((float)v2);
  }
}
//------------------------------------------------------
#if 0
void OnMessageHandler(unsigned char *buffer, int error_counter, int av_offset)
{
 printf("\r\n=================\r\nData: ");
 for(int i=0;i<12;i++)
  {
   printf("%02X ",buffer[i]);
  }


 printf("\r\nCorrected errors: %d ",error_counter);
 printf("\r\nSync offset: %d ",av_offset);

 return;
}
#endif

//------------------------------------------------------------
