
#include <math.h>
#include <limits.h>
#include "config.h"
#include "sinustable.h"
#include "fsktx.h"



//--------------------------------------------------------
TFsk33x5Transmitter::TFsk33x5Transmitter()
{
 Inited=0;
 PrevTone=0;
 OutCardSpeed=44100.0;
 SymbolLengthX=1024000;
 BufPointer=NULL;
 BufLen=0;
 Speed=25.0;
 DeltaFreq=Speed;
 Reverse=0;
}
//----------------------------------------------------
TFsk33x5Transmitter::~TFsk33x5Transmitter()
{
 //
}
//----------------------------------------------------
void TFsk33x5Transmitter::Init(double spd, double df, double cardspeed,int is_reverse)
{
 Speed=spd;
 OutCardSpeed=cardspeed;
 Reverse=is_reverse;

 SymbolLengthX= (int)(floor(OutCardSpeed*1000.0/spd +0.5)+0.1);
 DeltaFreq=df;

 BufPointer=NULL;
 BufLen=0;

 Reset();

 SetFreqs(1500.0); 

 Inited=1;
}
//----------------------------------------------------
void TFsk33x5Transmitter::Reset(void)
{
    PhaseX=0;
    SymPhase=0;
    PrevTone=0;
}
//----------------------------------------------------
void   TFsk33x5Transmitter::SetFreqs(double cfreq)
{
 double freq,df;
 int i;

 for(int i=0;i<33;i++)
  {
   FineFreqs[i]=(int)floor((cfreq+(double)(i-16)*DeltaFreq)*(double)FINE_SINUS_TABLE_LEN/OutCardSpeed+0.5);
  }

 FineFreqLow=FineFreqs[0];
 FineFreqHigh=FineFreqs[32];
}
//----------------------------------------------------
void TFsk33x5Transmitter::PlaySymbol(int symbol)
{   
 // �������� ���� IFSK-������ (0...31), �������������� � ���� ����
 static int SymToTone[32]={0,1,3,2,7,6,4,5,15,14,12,13,8,9,11,10,31,30,28,29,24,25,27,26,16,17,19,18,23,22,20,21};

 symbol=SymToTone[symbol&31];

 int tone,freq;

 if(Reverse)
  {
   tone=(PrevTone-symbol-1);
   if(tone<0) tone+=33;
  }
 else 
  {
   tone=(PrevTone+symbol+1);
   if(tone>32) tone-=33;
  }

 PrevTone=tone;

 freq=FineFreqs[tone];

 if(BufPointer==NULL) return; // �� ������ ����� ��� ������������ �������

 for(;SymPhase<SymbolLengthX;SymPhase+=1000) // �������� ���
  {
   BufLen++;
   PhaseX+= freq;
   PhaseX&= (FINE_SINUS_TABLE_LEN-1);
   *(BufPointer++)= SinusTable.FineSinusTable[PhaseX];
  }
 SymPhase-= SymbolLengthX;
}
//------------------------------------------------------------
void TFsk33x5Transmitter::SendSymbolEx(int sym)
{
 // write one 5bits-symbol  or special symbol

#if DEBUG_PRINT
 printf("\nSendSymbolEx: %d",sym);
 fflush(stdout);
#endif


 if((sym>=0) && (sym<32))
   {
    PlaySymbol(sym&31);  // ������������� � ��� ���� !!!!
    return;
   }

 // special symbols
 switch(sym)
  {
   case FSK33_5_START_SYM:
            // transmission start
#if DEBUG_PRINT
 printf("\nTones: ");
#endif
            Reset(); 
            FillTxOn();
            PlaySymbol(0); // !!!!!
            break;
  case FSK33_5_STOP_SYM:
            // transmission end
            PlaySymbol(0); // !!!!!
            FillTxOff();
#if DEBUG_PRINT
 printf(" end\n");
#endif
            break;
  }

}

//----------------------------------------------------------

void TFsk33x5Transmitter::FillTxOn(void)
{
 // transmission start
 int freq;

 if(BufPointer==NULL) return; // output buffer is not defined

 freq= FineFreqs[0];
 if(Reverse) PrevTone=1;
 else PrevTone=32;  // ����� ����� ���� ����� ���������� �� ���� 

 // silence
 for(int i=0;i<2;i++)
  {
   BufLen++;
   *(BufPointer++)= 0;
  }

  //int dsamp = (FINE_SINUS_TABLE_LEN/4)/(SymbolLengthX/1000);
  int dsamp = (FINE_SINUS_TABLE_LEN*250)/SymbolLengthX;
  if(dsamp<1) dsamp=1;

  PhaseX=0;
  for(int i=0;i<(FINE_SINUS_TABLE_LEN/4);i+=dsamp)  // raising sinus with length in one symbol
      {
       BufLen++;
       PhaseX+= freq;
       PhaseX&= (FINE_SINUS_TABLE_LEN-1);
       *(BufPointer++)= (s16_t)((((int)SinusTable.FineSinusTable[i])*((int)SinusTable.FineSinusTable[PhaseX]))/(int)SINUS_AMPLITUDE);
       }
}
//----------------------------------------------------------
void TFsk33x5Transmitter::FillTxOff(void)
{
 // transmission is end
 int freq= FineFreqs[PrevTone];

 //int dsamp = (FINE_SINUS_TABLE_LEN/4)/(SymbolLengthX/1000);
 int dsamp = (FINE_SINUS_TABLE_LEN*250)/SymbolLengthX;
 if(dsamp<1) dsamp=1;

 for(int i=FINE_SINUS_TABLE_LEN/4;i<(FINE_SINUS_TABLE_LEN/2);i+=dsamp)  // falling sinus with length of symbol
  {
   BufLen++;
   PhaseX+= freq;
   PhaseX&= (FINE_SINUS_TABLE_LEN-1);
   *(BufPointer++)= (s16_t)((((int)SinusTable.FineSinusTable[i])*((int)SinusTable.FineSinusTable[PhaseX]))/(int)SINUS_AMPLITUDE);
  }

 // silence
 for(int i=0;i<2;i++)
  {
   BufLen++;
   *(BufPointer++)= 0;
  }

}

//===============================================================================

