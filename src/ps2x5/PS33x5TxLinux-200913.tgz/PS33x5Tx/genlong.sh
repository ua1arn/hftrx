#!/bin/sh
./gentext 1500 8 fox.txt fox12_5.wav
./gentext 1500 16 fox.txt fox25.wav
./gentext 1500 32 fox.txt fox50.wav
./gentext 2000 64 fox.txt fox100.wav
