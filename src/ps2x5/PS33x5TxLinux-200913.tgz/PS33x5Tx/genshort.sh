#!/bin/sh
./gentext 1500 1
./gentext 1500 2
./gentext 1500 4
./gentext 1500 8
./gentext 1500 16
./gentext 1500 32
./gentext 2000 64
