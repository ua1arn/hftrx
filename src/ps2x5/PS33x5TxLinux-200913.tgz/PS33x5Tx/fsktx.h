#ifndef FSKTX_INCLUDE
#define FSKTX_INCLUDE
//--------------------------------------------------------

#include "config.h"
#include "sinustable.h"

#define FSK33_5_START_SYM 32
#define FSK33_5_STOP_SYM  33
                          
class TFsk33x5Transmitter
{
    private:
     int Inited;
     int SymbolLengthX; // symbols length in (1/1000 of sample)
     int PhaseX; // sound phase
     int SymPhase; // phase of symbol
     int FineFreqs[33]; // freqs in "small ticks"
     int PrevTone;
     int Reverse;
     double DeltaFreq; 
     double Speed;
     double OutCardSpeed;

     TSinusTable SinusTable;

     void FillTxOn(void);
     void FillTxOff(void);

    public:
     TFsk33x5Transmitter();
     ~TFsk33x5Transmitter();
     void Init(double spd, double df,  double cardspeed,int is_reverse);
     void   SetFreqs(double cfreq);
     void Reset(void);
     void SendSymbolEx(int sym);
     void PlaySymbol(int symbol);

     int FineFreqLow;
     int FineFreqHigh;
     s16_t *BufPointer; // current position in output buffer
     int   BufLen; // number of samples in output buffer
};
//--------------------------------------------------
#endif
