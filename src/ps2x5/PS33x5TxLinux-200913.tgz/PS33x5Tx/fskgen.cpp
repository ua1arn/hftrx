
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <fcntl.h>
#include <limits.h>

#include "config.h"
#include "fsktx.h"
#include "rs_code_u.h"
#include "wavwrite.h"
#include "crc16.h"
#include "fskgen.h"
                 

TFsk33x5Generator::TFsk33x5Generator()
{
 //
}

void TFsk33x5Generator::Init(double speed, double shift, double cfreq, double real_card_speed, int is_reverse)
{
 FskTx.Init(speed,shift,real_card_speed,is_reverse);
 FskTx.SetFreqs(cfreq);

 RsCoder.Init(8);
}


int TFsk33x5Generator::GenSymBuffer(u8_t data[7], u8_t block_num, int eot)
// return 0 on success
{
 memset(DataSymbols,0,sizeof(DataSymbols)); // to fill untransmitted bytes
 
 DataSymbols[0]= (data[0]>>3)&31;
 DataSymbols[1]= ((data[0]<<2)&(4+8+16)) | ((data[1]>>6)&3);
 DataSymbols[2]=  (data[1]>>1)&31;
 DataSymbols[3]= ((data[1]<<4)&16) | ((data[2]>>4)&15);
 DataSymbols[4]= ((data[2]<<1)&30) | ((data[3]>>7)&1);
 DataSymbols[5]=  (data[3]>>2)&31;
 DataSymbols[6]= ((data[3]<<3)&24) | ((data[4]>>5)&7);
 DataSymbols[7]=  data[4]&31;


 DataSymbols[8]= (data[5]>>3)&31;
 DataSymbols[9]= ((data[5]<<2)&(4+8+16)) | ((data[6]>>6)&3);
 DataSymbols[10]=  (data[6]>>1)&31;
 DataSymbols[11]= ((data[6]<<4)&16) | (block_num&15);


 u16_t crc=0xFFFF;
 for(int i=0;i<12;i++) crc=crc16ccit(DataSymbols[i],crc);
 
 if(eot) crc^=FSK2_5_EOT_CRC_MASK;
 else crc^=FSK2_5_CRC_MASK;

 DataSymbols[12]= (crc>>10)&31;
 DataSymbols[13]= (crc>>5)&31;
 DataSymbols[14]= crc&31;
 RsCoder.encode((char*)DataSymbols,(char*)ControlSymbols);

#if DEBUG_PRINT
 printf("\nEncoded: ");
 printf("\nEncoded: ");
 for(int i=0;i<16;i++) printf("%02X ",ControlSymbols[i]);
 printf("- ");
 for(int i=0;i<15;i++) printf("%02X ",DataSymbols[i]);
 printf("\n");
#endif

 return 0;
}



int TFsk33x5Generator::OpenWave(char *wave_file_name, int prefix_len)
// prefix_len - ����� �������� ��������
// ���������� ���� ��� ������
{
 if(WaveWriter.Open(wave_file_name,1,NOMINAL_SAMPLING_RATE,16)!=0) return -2;


 FskTx.BufPointer=SoundBuffer; // set output buffer
 FskTx.BufLen=0;
 FskTx.SendSymbolEx(FSK33_5_START_SYM);
 if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
  {
   WaveWriter.Close();
   return -3;
  }

 for(int i=0; i<prefix_len; i++)
  {
   FskTx.BufPointer=SoundBuffer; // set output buffer
   FskTx.BufLen=0;
   FskTx.SendSymbolEx(0);
   if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
    {
     WaveWriter.Close();
     return -4;
    }
  }

  return 0;
}
//--------------------------------------------------------
int TFsk33x5Generator::AddWave(u8_t data[7], u8_t block_num, int eot)
// return 0 on Success
{
 GenSymBuffer(data, block_num, eot);

  // block generating:
  for(int i=0; i<16; i++)
   {
    FskTx.BufPointer=SoundBuffer; // set output buffer
    FskTx.BufLen=0;
    FskTx.SendSymbolEx(ControlSymbols[i]);
    if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
     {
      WaveWriter.Close();
      return -4;
     }
   }

  for(int i=0; i<15; i++)
   {
    FskTx.BufPointer=SoundBuffer; // set output buffer
    FskTx.BufLen=0;
    FskTx.SendSymbolEx(DataSymbols[i]);
    if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
     {
      WaveWriter.Close();
      return -5;
     }
   }

 return 0; 
}

//---------------------------------------------------------
int TFsk33x5Generator::CloseWave(void)
// return 0 on Success
{
    FskTx.BufPointer=SoundBuffer; // set output buffer
    FskTx.BufLen=0;
    FskTx.SendSymbolEx(0);
    if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
     {
      WaveWriter.Close();
      return -5;
     }

  FskTx.BufPointer=SoundBuffer; // set output buffer
  FskTx.BufLen=0;
  FskTx.SendSymbolEx(0);
  FskTx.SendSymbolEx(FSK33_5_STOP_SYM);
  if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
   {
    WaveWriter.Close();
    return -6;
   }

 if(WaveWriter.Close()!=0) return -7;

 return 0; 
}
//---------------------------------------------------------
int TFsk33x5Generator::GenWave(u8_t data[7], u8_t block_num, char *wave_file_name)
// return 0 on Success
{
 if(WaveWriter.Open(wave_file_name,1,NOMINAL_SAMPLING_RATE,16)!=0) return -2;

 GenSymBuffer(data, block_num, 0);


  // block generating:


  FskTx.BufPointer=SoundBuffer; // set output buffer
  FskTx.BufLen=0;
  FskTx.SendSymbolEx(FSK33_5_START_SYM);
  if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
   {
    WaveWriter.Close();
    return -3;
   }


  FskTx.BufPointer=SoundBuffer; // set output buffer
  FskTx.BufLen=0;
  FskTx.SendSymbolEx(0);
  if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
   {
    WaveWriter.Close();
    return -13;
   }


  for(int i=0; i<16; i++)
   {
    FskTx.BufPointer=SoundBuffer; // set output buffer
    FskTx.BufLen=0;
    FskTx.SendSymbolEx(ControlSymbols[i]);
    if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
     {
      WaveWriter.Close();
      return -4;
     }
   }

  for(int i=0; i<15; i++)
   {
    FskTx.BufPointer=SoundBuffer; // set output buffer
    FskTx.BufLen=0;
    FskTx.SendSymbolEx(DataSymbols[i]);
    if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
     {
      WaveWriter.Close();
      return -5;
     }
   }


  FskTx.BufPointer=SoundBuffer; // set output buffer
  FskTx.BufLen=0;
  FskTx.SendSymbolEx(0);
  if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
   {
    WaveWriter.Close();
    return -16;
   }

  FskTx.BufPointer=SoundBuffer; // set output buffer
  FskTx.BufLen=0;
  FskTx.SendSymbolEx(FSK33_5_STOP_SYM);
  if(WaveWriter.Write(SoundBuffer,FskTx.BufLen)!=0)
   {
    WaveWriter.Close();
    return -6;
   }

 if(WaveWriter.Close()!=0) return -7;

 return 0; 
}

/*
                        0  1  2  3  4  5  6  7   8  9   10  11  12 13 14  15
static int SymToTone[]={0,1,3,2,7,6,4,5,15,14,12,13,8,9,11,10};
           SymToTone[]={0,1,3,2,7,6,4,5,15,14,12,13,8,9,11,10,31,30,28,29,24,25,27,26,16,17,19,18,23,22,20,21};


 
*/ 
