
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <fcntl.h>
#include <limits.h>

#include "config.h"
#include "fskgen.h"

TFsk33x5Generator FskGen;      
                  

char Str128[128];

int main(int argc, char* argv[])
{
 
 if(argc<3)
  {
   fprintf(stderr,"Usage: \r\n  %s center_freq speedx [input_file] [output_wave_file] \n",argv[0]);
   fprintf(stderr,"speedx = 1...64 or -64...-1 \n");
   fprintf(stderr,"speedx < 0 means reverse modulation (lsb) \n");
   fprintf(stderr,"input file \"-\" means stdin \n");
   exit(1);
  }


 double FskCenterFreq= 1500.0; // center freq
 if(argc>1)
  {
   FskCenterFreq=atof(argv[1]);
  }

 int Reverse= 0; 
 int SpeedX= 32; 
 if(argc>2)
  {
   SpeedX=atoi(argv[2]);
   if(SpeedX<0)
    {
     SpeedX= -SpeedX;
     Reverse=1;
    }
  }
 double SpeedHz= 1.5625*(double)SpeedX;

 double FskShift=SpeedHz; 
 if(SpeedHz<10.0) FskShift=SpeedHz*2.0;  

 char *FileName=(char*)"";
 if(argc>3)
  {
   FileName= argv[3];
  }

 char *OutputFileName=NULL;
 if(argc>4)
  {
   OutputFileName=argv[4];
  }


 if(OutputFileName==NULL)
  {
   sprintf(Str128,"txt%lu@%.2lf-%lf-%d.wav",(unsigned long)time(NULL),FskCenterFreq,SpeedHz,Reverse);
   OutputFileName=Str128;
  }


 printf("\nOutput File: %s \n",OutputFileName);
 printf("Center freq: %.2lf \n",FskCenterFreq);
 printf("Speed: %.2lf (x%d) \n",SpeedHz,SpeedX);
 printf("Shift: %.2lf \n",FskShift);
 printf("Reverse: %d \n",Reverse);
 if(FileName[0]) printf("Input File: %s \n",FileName);


 FILE *fin=NULL;

 if(FileName[0])
  {
   if(strcmp(FileName,"-")) fin=fopen(FileName,"rb");
   else fin=stdin;
   if(fin==NULL)
    {
     fprintf(stderr,"File open error! \r\n");
     exit(2);
    }
  }


 // set parameters:
 FskGen.Init(SpeedHz,FskShift,FskCenterFreq,(double)NOMINAL_SAMPLING_RATE,Reverse);

 int prefix_len= floor(3.0*SpeedHz+0.9); // ��� �������
 if(prefix_len<1) prefix_len=1;

 int rez=FskGen.OpenWave(OutputFileName,prefix_len);
 if(rez)
  {
   fprintf(stderr,"%s file open error! (%d) \n",OutputFileName,rez);
   if((strcmp(FileName,"-")) && (fin!=NULL)) fclose(fin);
   exit(1);
  }



 unsigned char Data[7]={0};
 unsigned char PktNum=8;
 int counter=0;


 int sym;
 if(fin!=NULL)
  {
   while((sym=fgetc(fin))!=EOF)
   {
    Data[counter++]=sym&255;
    if(counter<7) continue;

   // ������� ����
   counter=0;
   rez=FskGen.AddWave(Data,PktNum,0);
   if(rez)
    {
     fprintf(stderr,"%s file write error! (%d) \n",OutputFileName,rez);
     FskGen.CloseWave();
     if((strcmp(FileName,"-")) && (fin!=NULL)) fclose(fin);
     exit(2);
    }

   PktNum++;
   if(PktNum==8) PktNum=0;
   else if(PktNum==16) PktNum=0;
  }
  if((strcmp(FileName,"-")) && (fin!=NULL)) fclose(fin);

    // ��������� �������. ���� counter==0, ��������� ����� ����, ����� - ���������� ������
    Data[counter++]=EOT_SYM;
    for(;counter<7;counter++) Data[counter]=0;
    rez=FskGen.AddWave(Data,PktNum,1);
    if(rez)
     {
      fprintf(stderr,"%s file write error! (%d) \n",OutputFileName,rez);
      FskGen.CloseWave();
      exit(3);
     }
   


  rez=FskGen.CloseWave();
  if(rez)
   {
    fprintf(stderr,"%s file closing error! (%d) \n",OutputFileName,rez);
    FskGen.CloseWave();
    exit(4);
   }
    exit(0);
  }


 //------


 static char StrOut[1024];
 snprintf(StrOut,1023,"PS33x5 sample %.2lf Hz / %.4lf Bd \r\n�������� ����� 1234567890 \r\n�������� � ����������� %.2lf Hz / %.4lf Bd \r\n",FskCenterFreq,SpeedHz,FskCenterFreq,SpeedHz);
 StrOut[1023]=0;


  for(char *p=StrOut;*p;p++)
  {
   Data[counter++]= *p;
   if(counter<7) continue;

   // ������� ����
   counter=0;
   rez=FskGen.AddWave(Data,PktNum,0);
   if(rez)
    {
     fprintf(stderr,"%s file write error! (%d) \n",OutputFileName,rez);
     FskGen.CloseWave();
     exit(2);
    }

   PktNum++;
   if(PktNum==8) PktNum=0;
   else if(PktNum==16) PktNum=0;
 }

   // ��������� ������� ��� ������� ����� ����
   Data[counter++]=EOT_SYM;
   for(;counter<7;counter++) Data[counter]=0;
   rez=FskGen.AddWave(Data,PktNum,1);
   if(rez)
    {
     fprintf(stderr,"%s file write error! (%d) \n",OutputFileName,rez);
     FskGen.CloseWave();
     exit(3);
    }


  rez=FskGen.CloseWave();
  if(rez)
   {
    fprintf(stderr,"%s file closing error! (%d) \n",OutputFileName,rez);
    FskGen.CloseWave();
    exit(4);
   }
 
 exit(0);
  

 return 0;
}
                         
