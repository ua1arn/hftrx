#ifndef FSKTX_INCLUDE
#define FSKTX_INCLUDE
//--------------------------------------------------------

#include "config.h"
#include "sinustable.h"

#define FSK2_5_START_SYM (-1)
#define FSK2_5_STOP_SYM  (-2)
                          
class TFsk2x5Transmitter
{
    private:
     int Inited;
     int SymbolLengthX; // symbols length in (1/1000 of sample)
     int PhaseX; // sound phase
     int SymPhase; // phase of symbol
     int FineFreqs[2]; // freqs in "small ticks"
     int PrevTone;
     double DeltaFreq; 
     double Speed;
     double OutCardSpeed;

     TSinusTable SinusTable;

     void SendSymbol(int symbol);
     void FillTxOn(void);
     void FillTxOff(void);

    public:
     TFsk2x5Transmitter();
     ~TFsk2x5Transmitter();
     void Init(double spd, double df,  double cardspeed);
     void   SetFreqs(double minfreq);
     void Reset(void);
     void SendSymbolEx(int sym);
     void SendBit(int sbit);

     int FineFreqLow;
     int FineFreqHigh;
     s16_t *BufPointer; // current position in output buffer
     int   BufLen; // number of samples in output buffer
};
//--------------------------------------------------
#endif
