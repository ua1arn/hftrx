#ifndef RS_CODE_U_INCLUDE
#define RS_CODE_U_INCLUDE
//---------------------------------

#define RS_N  31        /* RS_N=2**RS_M -1   length of codeword */
#define RS_M   5          /* RS code over GF(2**8) - change to suit */

#define RS_T_MAX   15  /* number of errors that can be corrected */
#define RS_K_MAX   29  /* RS_K = RS_N-2*RS_T  */
  
#include "config.h"
     
class TRSuni
 {
  public:
    TRSuni();
    void Init(int rs_t);
    void encode(char *data, char *bb);
    int decode(char *input, signed char *recd);

  private:
    void generate_gf(void);
    void gen_poly(void);

    int RsT;
    int RsK;
    int pp [RS_M+1]; //  GF(64): 67, 91, 97, 103, 109, 115 /* specify irreducible polynomial coeffts */
    int alpha_to [RS_N+1], index_of [RS_N+1], gg [RS_N+1] ;

    int root[RS_T_MAX];
    int loc[RS_T_MAX];
    int z[RS_T_MAX+1];
    int err[RS_N];
    int reg[RS_T_MAX+1];

    int elp[RS_N+2][RS_N];
    int d[RS_N+2];
    int l[RS_N+2];
    int u_lu[RS_N+2];
    int s[RS_N+1];
 };

                 
                 



//---------------------------------
#endif
