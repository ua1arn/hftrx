#ifndef CRC16_INCLUDED
#define CRC16_INCLUDED
//-----
unsigned short crc16ccit(unsigned char sym, unsigned short  crc);
//-------
#endif

