
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "config.h" 
#include "rs_code_u.h"

                   

             
TRSuni::TRSuni()
{
 int tmp[]= {1,0, 0,1,0,1};   // x**5 + x**2 + 1
 memcpy(pp,tmp,sizeof(pp));
 Init(8);
}
     
     
void TRSuni::Init(int rs_t)
{
 RsT=rs_t;
 RsK = RS_N-2*RsT;

 generate_gf();
 gen_poly();
}


void  TRSuni::generate_gf(void)
/* generate GF(2**RS_M) from the irreducible polynomial p(X) in pp[0]..pp[RS_M]
   lookup tables:  index->polynomial form   alpha_to[] contains j=alpha**i;
                   polynomial form -> index form  index_of[j=alpha**i] = i
   alpha=2 is the primitive element of GF(2**RS_M)
*/
 {
    int i, mask ;

  mask = 1 ;
  alpha_to[RS_M] = 0 ;
  for (i=0; i<RS_M; i++)
   { alpha_to[i] = mask ;
     index_of[alpha_to[i]] = i ;
     if (pp[i]!=0)
       alpha_to[RS_M] ^= mask ;
     mask <<= 1 ;
   }
  index_of[alpha_to[RS_M]] = RS_M ;
  mask >>= 1 ;
  for (i=RS_M+1; i<RS_N; i++)
   { if (alpha_to[i-1] >= mask)
        alpha_to[i] = alpha_to[RS_M] ^ ((alpha_to[i-1]^mask)<<1) ;
     else alpha_to[i] = alpha_to[i-1]<<1 ;
     index_of[alpha_to[i]] = i ;
   }
  index_of[0] = -1 ;
 }


void TRSuni::gen_poly(void)
/* Obtain the generator polynomial of the RS_T-error correcting, length
  RS_N=(2**RS_M -1) Reed Solomon code  from the product of (X+alpha**i), i=1..2*RS_T
*/
 {
    int i,j ;

   gg[0] = 2 ;    /* primitive element alpha = 2  for GF(2**RS_M)  */
   gg[1] = 1 ;    /* g(x) = (X+alpha) initially */
   for (i=2; i<=(RS_N-RsK); i++)
    { gg[i] = 1 ;
      for (j=i-1; j>0; j--)
        if (gg[j] != 0)  gg[j] = gg[j-1]^ alpha_to[(index_of[gg[j]]+i)%RS_N] ;
        else gg[j] = gg[j-1] ;
      gg[0] = alpha_to[(index_of[gg[0]]+i)%RS_N] ;     /* gg[0] can never be zero */
    }
   /* convert gg[] to index form for quicker encoding */
   for (i=0; i<=(RS_N-RsK); i++)  gg[i] = index_of[gg[i]] ;
 }


void TRSuni::encode(char *data, char *bb)
/* take the string of symbols in data[i], i=0..(k-1) and encode systematically
   to produce 2*RS_T parity symbols in bb[0]..bb[2*RS_T-1]
   data[] is input and bb[] is output in polynomial form.
   Encoding is done by using a feedback shift register with appropriate
   connections specified by the elements of gg[], which was generated above.
   Codeword is   c(X) = data(X)*X**(RS_N-RS_K)+ b(X)          */
 {
    int i,j ;
   int feedback ;

   for (i=0; i<(RS_N-RsK); i++)   bb[i] = 0 ;
   for (i=RsK-1; i>=0; i--)
    {  feedback = index_of[data[i]^bb[RS_N-RsK-1]] ;
       if (feedback != -1)
        { for (j=RS_N-RsK-1; j>0; j--)
            if (gg[j] != -1)
              bb[j] = bb[j-1]^alpha_to[(gg[j]+feedback)%RS_N] ;
            else
              bb[j] = bb[j-1] ;
          bb[0] = alpha_to[(gg[0]+feedback)%RS_N] ;
        }
       else
        { for (j=(RS_N-RsK-1); j>0; j--)
            bb[j] = bb[j-1] ;
          bb[0] = 0 ;
        } ;
    } ;
 } ;



int TRSuni::decode(char *input, signed char *recd)
// returns not 0  if uncorrectable errors found

/* assume we have received bits grouped into RS_M-bit symbols in recd[i],
   i=0..(RS_N-1),  and recd[i] is index form (ie as powers of alpha).
   We first compute the 2*RS_T syndromes by substituting alpha**i into rec(X) and
   evaluating, storing the syndromes in s[i], i=1..2RS_T (leave s[0] zero) .
   Then we use the Berlekamp iteration to find the error location polynomial
   elp[i].   If the degree of the elp is >RS_T, we cannot correct all the errors
   and hence just put out the information symbols uncorrected. If the degree of
   elp is <=RS_T, we substitute alpha**i , i=1..n into the elp to get the roots,
   hence the inverse roots, the error location numbers. If the number of errors
   located does not equal the degree of the elp, we have more than RS_T errors
   and cannot correct them.  Otherwise, we then solve for the error value at
   the error location and correct the error.  The procedure is that found in
   Lin and Costello. For the cases where the number of errors is known to be too
   large to correct, the information symbols as received are output (the
   advantage of systematic encoding is that hopefully some of the information
   symbols will be okay and that if we are in luck, the errors are in the
   parity part of the transmitted codeword).  Of course, these insoluble cases
   can be returned as error flags to the calling routine if desired.   */
 {
   int i,j,u,q ;
   int cnt, syn_error=0; 
   int rez=0;


   for (i=0; i<RS_N; i++)
      recd[i] = index_of[input[i]] ;          /* put recd[i] into index form */


/* first form the syndromes */
   for (i=1; i<=(RS_N-RsK); i++)
    { s[i] = 0 ;
      for (j=0; j<RS_N; j++)
        if (recd[j]!=-1)
          s[i] ^= alpha_to[(recd[j]+i*j)%RS_N] ;      /* recd[j] in index form */
/* convert syndrome from polynomial form to index form  */
      if (s[i]!=0)  syn_error=1 ;        /* set flag if non-zero syndrome => error */
      s[i] = index_of[s[i]] ;
    } ;

   if (syn_error)       /* if errors, try and correct */
    {
/* compute the error location polynomial via the Berlekamp iterative algorithm,
   following the terminology of Lin and Costello :   d[u] is the 'mu'th
   discrepancy, where u='mu'+1 and 'mu' (the Greek letter!) is the step number
   ranging from -1 to 2*RS_T (see L&C),  l[u] is the
   degree of the elp at that step, and u_l[u] is the difference between the
   step number and the degree of the elp.
*/
/* initialise table entries */
      d[0] = 0 ;           /* index form */
      d[1] = s[1] ;        /* index form */
      elp[0][0] = 0 ;      /* index form */
      elp[1][0] = 1 ;      /* polynomial form */
      for (i=1; i<(RS_N-RsK); i++)
        { elp[0][i] = -1 ;   /* index form */
          elp[1][i] = 0 ;   /* polynomial form */
        }
      l[0] = 0 ;
      l[1] = 0 ;
      u_lu[0] = -1 ;
      u_lu[1] = 0 ;
      u = 0 ;

      do
      {
        u++ ;
        if (d[u]==-1)
          { l[u+1] = l[u] ;
            for (i=0; i<=l[u]; i++)
             {  elp[u+1][i] = elp[u][i] ;
                elp[u][i] = index_of[elp[u][i]] ;
             }
          }
        else
/* search for words with greatest u_lu[q] for which d[q]!=0 */
          { q = u-1 ;
            while ((d[q]==-1) && (q>0)) q-- ;
/* have found first non-zero d[q]  */
            if (q>0)
             { j=q ;
               do
               { j-- ;
                 if ((d[j]!=-1) && (u_lu[q]<u_lu[j]))
                   q = j ;
               }while (j>0) ;
             } ;

/* have now found q such that d[u]!=0 and u_lu[q] is maximum */
/* store degree of new elp polynomial */
            if (l[u]>l[q]+u-q)  l[u+1] = l[u] ;
            else  l[u+1] = l[q]+u-q ;

/* form new elp(x) */
            for (i=0; i<(RS_N-RsK); i++)    elp[u+1][i] = 0 ;
            for (i=0; i<=l[q]; i++)
              if (elp[q][i]!=-1)
                elp[u+1][i+u-q] = alpha_to[(d[u]+RS_N-d[q]+elp[q][i])%RS_N] ;
            for (i=0; i<=l[u]; i++)
              { elp[u+1][i] ^= elp[u][i] ;
                elp[u][i] = index_of[elp[u][i]] ;  /*convert old elp value to index*/
              }
          }
        u_lu[u+1] = u-l[u+1] ;

/* form (u+1)th discrepancy */
        if (u<(RS_N-RsK))    /* no discrepancy computed on last iteration */
          {
            if (s[u+1]!=-1)
                   d[u+1] = alpha_to[s[u+1]] ;
            else
              d[u+1] = 0 ;
            for (i=1; i<=l[u+1]; i++)
              if ((s[u+1-i]!=-1) && (elp[u+1][i]!=0))
                d[u+1] ^= alpha_to[(s[u+1-i]+index_of[elp[u+1][i]])%RS_N] ;
            d[u+1] = index_of[d[u+1]] ;    /* put d[u+1] into index form */
          }
      } while ((u<(RS_N-RsK)) && (l[u+1]<=RsT)) ;

      u++ ;
      
      if (l[u]>RsT)
       {
        rez= -l[u];
        //memset(decoded,0,RS_N);
        return rez;
       }

      if (l[u]<=RsT)         /* can correct error */
       {
/* put elp into index form */
         for (i=0; i<=l[u]; i++)   elp[u][i] = index_of[elp[u][i]] ;

/* find roots of the error location polynomial */
         for (i=1; i<=l[u]; i++)
           reg[i] = elp[u][i] ;
         cnt = 0 ;
         
         for (i=1; i<=RS_N; i++)
          {  q = 1 ;
             for (j=1; j<=l[u]; j++)
              if (reg[j]!=-1)
                { reg[j] = (reg[j]+j)%RS_N ;
                  q ^= alpha_to[reg[j]] ;
                } 
             
                if (!q)        /* store root and error location number indices */
              { root[cnt] = i;
                loc[cnt] = RS_N-i ;
                cnt++ ;
              }
          } 

         if (cnt!=l[u])
          {
           rez=cnt+1;
           //memset(recd,0,RS_N);
           return rez;
          }

         if (cnt==l[u])    /* no. roots = degree of elp hence <= RS_T errors */
          {
/* form polynomial z(x) */
           for (i=1; i<=l[u]; i++)        /* Z[0] = 1 always - do not need */
            { if ((s[i]!=-1) && (elp[u][i]!=-1))
                 z[i] = alpha_to[s[i]] ^ alpha_to[elp[u][i]] ;
              else if ((s[i]!=-1) && (elp[u][i]==-1))
                      z[i] = alpha_to[s[i]] ;
                   else if ((s[i]==-1) && (elp[u][i]!=-1))
                          z[i] = alpha_to[elp[u][i]] ;
                        else
                          z[i] = 0 ;
              for (j=1; j<i; j++)
                if ((s[j]!=-1) && (elp[u][i-j]!=-1))
                   z[i] ^= alpha_to[(elp[u][i-j] + s[j])%RS_N] ;
              z[i] = index_of[z[i]] ;         /* put into index form */
            } ;

  /* evaluate errors at locations given by error location numbers loc[i] */
           for (i=0; i<RS_N; i++)
             { err[i] = 0 ;
               if (recd[i]!=-1)        /* convert recd[] to polynomial form */
                 recd[i] = alpha_to[recd[i]] ;
               else  recd[i] = 0 ;
             }
           for (i=0; i<l[u]; i++)    /* compute numerator of error term first */
            { err[loc[i]] = 1;       /* accounts for z[0] */
              for (j=1; j<=l[u]; j++)
                if (z[j]!=-1)
                  err[loc[i]] ^= alpha_to[(z[j]+j*root[i])%RS_N] ;
              if (err[loc[i]]!=0)
               { err[loc[i]] = index_of[err[loc[i]]] ;
                 q = 0 ;     /* form denominator of error term */
                 for (j=0; j<l[u]; j++)
                   if (j!=i)
                     q += index_of[1^alpha_to[(loc[j]+root[i])%RS_N]] ;
                 q = q % RS_N ;
                 err[loc[i]] = alpha_to[(err[loc[i]]-q+RS_N)%RS_N] ;
                 recd[loc[i]] ^= err[loc[i]] ;  /*recd[i] must be in polynomial form */
               }
            }
          }
         else    /* no. roots != degree of elp => >RS_T errors and cannot solve */
           for (i=0; i<RS_N; i++)        /* could return error flag if desired */
               if (recd[i]!=-1)        /* convert recd[] to polynomial form */
                 recd[i] = alpha_to[recd[i]] ;
               else  recd[i] = 0 ;     /* just output received codeword as is */
       }
     else         /* elp has degree has degree >RS_T hence caRS_Not solve */
       for (i=0; i<RS_N; i++)       /* could return error flag if desired */
          if (recd[i]!=-1)        /* convert recd[] to polynomial form */
            recd[i] = alpha_to[recd[i]] ;
          else  recd[i] = 0 ;     /* just output received codeword as is */
    }
   else       /* no non-zero syndromes => no errors: output received codeword */
    for (i=0; i<RS_N; i++)
       if (recd[i]!=-1)        /* convert recd[] to polynomial form */
         recd[i] = alpha_to[recd[i]] ;
       else  recd[i] = 0 ;


       if(rez)
        {
         //memset(recd,0,RS_N);
         return rez;
        }
       return 0;
 }



