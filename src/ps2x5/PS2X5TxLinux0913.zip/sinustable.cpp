
#include <math.h>
#include <limits.h>
#include "config.h"
#include "sinustable.h"



//--------------------------------------------------------
TSinusTable::TSinusTable()
{
  // Create sinus table
 for(u32_t i=0;i<FINE_SINUS_TABLE_LEN;i++)
   {
    FineSinusTable[i]=(s16_t)(floor((double)SINUS_AMPLITUDE*sin((2.0*3.14159265358)*(double)i/(double)FINE_SINUS_TABLE_LEN)+0.5)+0.1);
   }
}
//----------------------------------------------------

