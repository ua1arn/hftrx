
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "config.h"
#include "rs_code_u.h"

TRSuni RsCoder;
                        
#define RS_T_TEST 8
#define RS_N_TEST 31
#define RS_K_TEST (RS_N_TEST-2*RS_T_TEST)

int main(int argc, char *argv[])
{
 int AddErrors=8;

 u8_t idata[RS_K_TEST];
 u8_t ibb[RS_T_TEST*2];
 u8_t send[RS_N_TEST];
 u8_t rcv[RS_N_TEST];



  if(argc>1) AddErrors=atoi(argv[1]);


/* for known data, stick a few numbers into a zero codeword. Data is in
   polynomial form.
*/
for  (int i=0; i<RS_K_TEST; i++)   idata[i] = 0 ;

/* for example, say we transmit the following message (nothing special!) */

randomize();          
idata[0] = rand()&0x1F;
idata[1] = rand()&0x1F;
idata[2] = rand()&0x1F;
idata[3] = rand()&0x1F;
idata[4] = rand()&0x1F;
idata[5] = rand()&0x1F;
idata[6] = rand()&0x1F;
idata[7] = rand()&0x1F;
idata[8] = rand()&0x1F;
idata[9] = rand()&0x1F;
idata[10] = rand()&0x1F;
idata[11] = rand()&0x1F;
idata[12] = rand()&0x1F;
idata[13] = rand()&0x1F;
idata[14] = rand()&0x1F;


/* encode idata[] to produce parity in ibb[].  Data input and parity output
   is in polynomial form
*/
 RsCoder.Init(8);

 RsCoder.encode(idata,ibb) ;

/* put the transmitted codeword, made up of data plus parity, in recd[] */
  for (int i=0; i<(RS_N_TEST-RS_K_TEST); i++)  send[i] = ibb[i] ;
  for (int i=0; i<RS_K_TEST; i++) send[i+RS_N_TEST-RS_K_TEST] = idata[i] ;

/* if you want to test the program, corrupt some of the elements of recd[]
   here. This can also be done easily in a debugger. */
/* Again, lets say that a middle element is changed */

  for(int i=0;i<AddErrors;i++) send[random(255)&31]^= (random(255)&31);

 
/* decode recv[] */
  int rez=RsCoder.decode(send,rcv) ;         /* rcv[] is returned in polynomial form */

  int ctr_err=0;
  int data_err=0;


/* print out the relevant stuff - initial and decoded {parity and message} */
  printf("Results for Reed-Solomon code (n=%3d, k=%3d, t= %3d)\n\n",RS_N_TEST,RS_K_TEST,RS_T_TEST) ;
  printf("  i  data[i]  send[i]  rcv[i](decoded)   (data, send, rcv in polynomial form)\n");
  for (int i=0; i<(RS_N_TEST-RS_K_TEST); i++)
   {
    printf("%3d    %3d      %3d      %3d\n",i, ibb[i],send[i], rcv[i]) ;
    if(ibb[i]!=rcv[i]) ctr_err++;
   }

    printf("\n");


  for (int i=RS_N_TEST-RS_K_TEST; i<RS_N_TEST; i++)
    {
       printf("%3d    %3d      %3d      %3d\n",i, idata[i-RS_N_TEST+RS_K_TEST], send[i], rcv[i]) ;
       if(idata[i-RS_N_TEST+RS_K_TEST]!=rcv[i]) data_err++;
   }

  printf("\nDecode rezult: %d \n",rez);
  printf("Ctr.errors: %d Data.errors: %d \n",ctr_err,data_err);
  return 0;
}


