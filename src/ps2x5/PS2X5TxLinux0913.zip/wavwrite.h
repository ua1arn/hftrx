#ifndef WAVEWRITE_INCLUDE
#define WAVEWRITE_INCLUDE
//-------------------------------------------------------

#include "config.h"

#if !FOR_LINUX
#include <vcl.h>
#endif

#include <stdio.h>


typedef struct {
  long           chunkSize;
  unsigned short wChannels;
  unsigned long  dwSamplesPerSec;
  unsigned long  dwAvgBytesPerSec;
  unsigned short wBlockAlign;
  unsigned short wBitsPerSample;
} FormatChunk;

class TWaveWrite
 {
   private:
    FILE *WaveFile;
    FormatChunk Format;
    unsigned long DataLen;
    int NotFlushedData;

    int   ReNewHeader(void);
   public:

    TWaveWrite();
    ~TWaveWrite();
    int   Open(char *filename, int channels, int samplesrate, int bitspersample);
    int   Write(void *buffer, int samples);
    int   Close(void);
 };

//-------------------------------------------------------
#endif
