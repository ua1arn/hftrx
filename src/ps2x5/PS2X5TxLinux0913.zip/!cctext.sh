#!/bin/sh
g++ gentext.cpp fskgen.cpp fsktx.cpp rs_code_u.cpp sinustable.cpp wavwrite.cpp crc16.cpp -o gentext

