
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <fcntl.h>
#include <limits.h>
#include <time.h>

#include "config.h"
#include "fskgen.h"

TFsk2x5Generator FskGen;      
                  

char Str128[128];

int main(int argc, char* argv[])
{
 
 
 double FskCenterFreq= 1700.0; // center freq
 int cfreq= 1700;


 if(argc<4)
  {
   fprintf(stderr,"Usage: \r\n  %s center_freq speed shift [input_file] [output_wave_file] \r\n",argv[0]);
   fprintf(stderr,"input file \"-\" means stdin \r\n");
   exit(1);
  }

 if(argc>1)
  {
   cfreq=atoi(argv[1]);
   FskCenterFreq= (double)cfreq;
  }


 double FskSpeed= 50.0; 
 int speed= 50;
 if(argc>2)
  {
   speed=atoi(argv[2]);
   FskSpeed= (double)speed;
  }


 double FskShift= 50.0; 
 int shift= 50;
 if(argc>3)
  {
   shift=atoi(argv[3]);
   FskShift= (double)shift;
  }

 char *FileName="";
 if(argc>4)
  {
   FileName= argv[4];
  }

 char *OutputFileName=NULL;
 if(argc>5)
  {
   OutputFileName=argv[5];
  }


 if(OutputFileName==NULL)
  {
   sprintf(Str128,"txt%lu@%d-%d-%d.wav",(unsigned long)time(NULL),cfreq,speed,shift);
   OutputFileName=Str128;
  }


 printf("\nOutput File: %s \n",OutputFileName);
 printf("Center freq: %.2lf \n",FskCenterFreq);
 printf("Speed: %.2lf \n",FskSpeed);
 printf("Shift: %.2lf \n",FskShift);
 if(FileName[0]) printf("Input File: %s \n",FileName);


 FILE *fin=NULL;

 if(FileName[0])
  {
   if(strcmp(FileName,"-")) fin=fopen(FileName,"rb");
   else fin=stdin;
   if(fin==NULL)
    {
     fprintf(stderr,"File open error! \r\n");
     exit(2);
    }
  }


 // set parameters:
 FskGen.Init(FskSpeed,FskShift,FskCenterFreq,(double)NOMINAL_SAMPLING_RATE);

 int prefix_len=(3*(int)FskSpeed+4)/5; // ��� �������
 if(prefix_len<1) prefix_len=1;

 int rez=FskGen.OpenWave(OutputFileName,prefix_len);
 if(rez)
  {
   fprintf(stderr,"%s file open error! (%d) \n",OutputFileName,rez);
   if((strcmp(FileName,"-")) && (fin!=NULL)) fclose(fin);
   exit(1);
  }



 unsigned char Data[7]={0};
 unsigned char PktNum=8;
 int counter=0;

 int sym;
 if(fin!=NULL)
  {
   while((sym=fgetc(fin))!=EOF)
   {
    Data[counter++]=sym&255;
    if(counter<7) continue;

   // ������� ����
   counter=0;
   rez=FskGen.AddWave(Data,PktNum,0);
   if(rez)
    {
     fprintf(stderr,"%s file write error! (%d) \n",OutputFileName,rez);
     FskGen.CloseWave();
     if((strcmp(FileName,"-")) && (fin!=NULL)) fclose(fin);
     exit(2);
    }

   PktNum++;
   if(PktNum==8) PktNum=0;
   else if(PktNum==16) PktNum=0;
  }
  if((strcmp(FileName,"-")) && (fin!=NULL)) fclose(fin);

    // ��������� �������. ���� counter==0, ��������� ����� ����, ����� - ���������� ������
    Data[counter++]=EOT_SYM;
    for(;counter<7;counter++) Data[counter]=0;
    rez=FskGen.AddWave(Data,PktNum,1);
    if(rez)
     {
      fprintf(stderr,"%s file write error! (%d) \n",OutputFileName,rez);
      FskGen.CloseWave();
      exit(3);
     }
   


  rez=FskGen.CloseWave();
  if(rez)
   {
    fprintf(stderr,"%s file closing error! (%d) \n",OutputFileName,rez);
    FskGen.CloseWave();
    exit(4);
   }
    exit(0);
  }

 //------

  static char StrOut[1024];
  snprintf(StrOut,1023,"PS2x5 sample %d Hz / %d Bd / %d Hz \r\n�������� ����� 1234567890 \r\n�������� � ����������� %d Hz / %d Bd / %d Hz \r\n",cfreq,speed,shift,cfreq,speed,shift);
  StrOut[1023]=0;


   for(char *p=StrOut;*p;p++)
   {
    Data[counter++]= *p;
    if(counter<7) continue;

    // ������� ����
    counter=0;
    rez=FskGen.AddWave(Data,PktNum,0);
    if(rez)
     {
      fprintf(stderr,"%s file write error! (%d) \n",OutputFileName,rez);
      FskGen.CloseWave();
      exit(2);
     }

    PktNum++;
    if(PktNum==8) PktNum=0;
    else if(PktNum==16) PktNum=0;
  }

    // ��������� ������� ��� ������� ����� ����
    Data[counter++]=EOT_SYM;
    for(;counter<7;counter++) Data[counter]=0;
    rez=FskGen.AddWave(Data,PktNum,1);
    if(rez)
     {
      fprintf(stderr,"%s file write error! (%d) \n",OutputFileName,rez);
      FskGen.CloseWave();
      exit(3);
     }
   


  rez=FskGen.CloseWave();
  if(rez)
   {
    fprintf(stderr,"%s file closing error! (%d) \n",OutputFileName,rez);
    FskGen.CloseWave();
    exit(4);
   }
 
 exit(0);
  

 return 0;
}
                         
