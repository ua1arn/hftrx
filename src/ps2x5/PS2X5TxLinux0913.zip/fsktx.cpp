
#include <math.h>
#include <limits.h>
#include "config.h"
#include "sinustable.h"
#include "fsktx.h"



//--------------------------------------------------------
TFsk2x5Transmitter::TFsk2x5Transmitter()
{
 Inited=0;
 PrevTone=0;
 OutCardSpeed=44100.0;
 SymbolLengthX=1024000;
 BufPointer=NULL;
 BufLen=0;
 Speed=25.0;
 DeltaFreq=Speed;
}
//----------------------------------------------------
TFsk2x5Transmitter::~TFsk2x5Transmitter()
{
 //
}
//----------------------------------------------------
void TFsk2x5Transmitter::Init(double spd, double df, double cardspeed)
{
 Speed=spd;
 OutCardSpeed=cardspeed;

 SymbolLengthX= (int)(floor(OutCardSpeed*1000.0/spd +0.5)+0.1);
 DeltaFreq=df;

 BufPointer=NULL;
 BufLen=0;

 Reset();

 SetFreqs(1700.0); 

 Inited=1;
}
//----------------------------------------------------
void TFsk2x5Transmitter::Reset(void)
{
    PhaseX=0;
    SymPhase=0;
    PrevTone=0;
}
//----------------------------------------------------
void   TFsk2x5Transmitter::SetFreqs(double cfreq)
{

 double freq,df;
 int i;

 FineFreqs[0]=(int)floor((cfreq-DeltaFreq/2.0)*(double)FINE_SINUS_TABLE_LEN/OutCardSpeed+0.5);
 FineFreqs[1]=(int)floor((cfreq+DeltaFreq/2.0)*(double)FINE_SINUS_TABLE_LEN/OutCardSpeed+0.5);


 FineFreqLow=FineFreqs[0];
 FineFreqHigh=FineFreqs[1];
}
//----------------------------------------------------
void TFsk2x5Transmitter::SendBit(int sbit)
{   
 // 0 - ����� ����
 // 1 - ��� �� ���


 int tone;

 if(sbit) tone=PrevTone;
 else 
  {
   tone= (PrevTone^1)&1;
   PrevTone=tone;
  }
  
 int freq=FineFreqs[tone];

#if DEBUG_PRINT
 printf("%d",tone);
#endif


 if(BufPointer==NULL) return; // output buffer is not defined

 for(;SymPhase<SymbolLengthX;SymPhase+=1000) // write a symbol 
  {
   BufLen++;
   PhaseX+= freq;
   PhaseX&= (FINE_SINUS_TABLE_LEN-1);
   *(BufPointer++)= SinusTable.FineSinusTable[PhaseX];
  }
 SymPhase-= SymbolLengthX;
}
//-----------------------------------------------------------------------

void   TFsk2x5Transmitter::SendSymbol(int symbol)
{   
 // write one 5-Bits symbol (0...31) to a buffer
 // �������, ������� �� �������� ����

 for(int i=0;i<5;i++)
  {
   if(symbol&16) SendBit(1);
   else SendBit(0);
   symbol<<=1;
  }
}
//-----------------------------------------------------------------------
void TFsk2x5Transmitter::SendSymbolEx(int sym)
{
 // write one 5bits-symbol  or special symbol

 if((sym>=0) && (sym<32))
   {
    SendSymbol(sym&31);
    return;
   }

 // special symbols
 switch(sym)
  {
   case FSK2_5_START_SYM:
            // transmission start
#if DEBUG_PRINT
 printf("\nTones: ");
#endif
            Reset(); 
            FillTxOn();
            SendSymbol(0);
            break;
  case FSK2_5_STOP_SYM:
            // transmission end
            SendSymbol(0);
            FillTxOff();
#if DEBUG_PRINT
 printf(" end\n");
#endif
            break;
  }

}

//----------------------------------------------------------

void TFsk2x5Transmitter::FillTxOn(void)
{
 // transmission start
 int freq;

 if(BufPointer==NULL) return; // output buffer is not defined

 freq= FineFreqs[0];
 PrevTone=1;  // ����� ����� ���� ����� ���������� �� ���� 

 // silence
 for(int i=0;i<2;i++)
  {
   BufLen++;
   *(BufPointer++)= 0;
  }

  //int dsamp = (FINE_SINUS_TABLE_LEN/4)/(SymbolLengthX/1000);
  int dsamp = (FINE_SINUS_TABLE_LEN*250)/SymbolLengthX;
  if(dsamp<1) dsamp=1;

  PhaseX=0;
  for(int i=0;i<(FINE_SINUS_TABLE_LEN/4);i+=dsamp)  // raising sinus with length in one symbol
      {
       BufLen++;
       PhaseX+= freq;
       PhaseX&= (FINE_SINUS_TABLE_LEN-1);
       *(BufPointer++)= (s16_t)((((int)SinusTable.FineSinusTable[i])*((int)SinusTable.FineSinusTable[PhaseX]))/(int)SINUS_AMPLITUDE);
       }
}
//----------------------------------------------------------
void TFsk2x5Transmitter::FillTxOff(void)
{
 // transmission is end
 int freq= FineFreqs[PrevTone&1];

 //int dsamp = (FINE_SINUS_TABLE_LEN/4)/(SymbolLengthX/1000);
 int dsamp = (FINE_SINUS_TABLE_LEN*250)/SymbolLengthX;
 if(dsamp<1) dsamp=1;

 for(int i=FINE_SINUS_TABLE_LEN/4;i<(FINE_SINUS_TABLE_LEN/2);i+=dsamp)  // falling sinus with length of symbol
  {
   BufLen++;
   PhaseX+= freq;
   PhaseX&= (FINE_SINUS_TABLE_LEN-1);
   *(BufPointer++)= (s16_t)((((int)SinusTable.FineSinusTable[i])*((int)SinusTable.FineSinusTable[PhaseX]))/(int)SINUS_AMPLITUDE);
  }

 // silence
 for(int i=0;i<2;i++)
  {
   BufLen++;
   *(BufPointer++)= 0;
  }

}

//===============================================================================

