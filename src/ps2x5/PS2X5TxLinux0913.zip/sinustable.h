#ifndef SINUSTABLE_INCLUDE
#define SINUSTABLE_INCLUDE
//--------------------------------------------------------

#include "config.h"

class TSinusTable
{

    public:
     TSinusTable();
     s16_t FineSinusTable[FINE_SINUS_TABLE_LEN];
};
//--------------------------------------------------
#endif
