#ifndef SOCKUDP_INCLUDE
#define SOCKUDP_INCLUDE
//--------------------------------------------------------

#include "config.h"
 
#if FOR_LINUX
#define SOCKET int
#define INVALID_SOCKET  (SOCKET)(~0)
#define SOCKET_ERROR            (-1)
#else
#include <winsock2.h>
#endif
             
struct TSockUdp
 {
    SOCKET St;
    struct sockaddr_in Peer;
    int Error;
    struct sockaddr_in FromAddr;
    struct sockaddr_in ToAddr;
    struct sockaddr_in RecvFromAddr;
 };



 void Sudp_Create(struct TSockUdp *me);
 void Sudp_Destroy(struct TSockUdp *me);
 int Sudp_SetAddress(struct TSockUdp *me,char *hname, char *sname, struct sockaddr_in *sap, char *protocol);
 int Sudp_Open(struct TSockUdp *me,char *localhost, char *localport, char *remotehost, char *remoteport);
 int Sudp_Send(struct TSockUdp *me,unsigned char *data,int len);
 int Sudp_SendTo(struct TSockUdp *me,char *remotehost, char *remoteport, unsigned char *data,int len);
 int Sudp_Receive(struct TSockUdp *me,unsigned char *data,int maxlen, int timeout, int *len);
 void Sudp_Close(struct TSockUdp *me);


//-------------------------------------------------------
#endif
