unsigned short crc16(unsigned char sym, unsigned short crc);
unsigned short crc16ccit(unsigned char sym, unsigned short  crc);
unsigned long crc32(unsigned char sym, unsigned long crc);
int CheckAx25Crc(unsigned char *buf, int cnt);
void AddAx25Crc(short *buf, int len);
unsigned char crc4itu(unsigned char data, unsigned char crc);


