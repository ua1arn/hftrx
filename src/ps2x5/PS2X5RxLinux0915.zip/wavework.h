#ifndef WAVEWORK_INCLUDE
#define WAVEWORK_INCLUDE
//--------------------------------------------------------
#include <windows.h>
#include <mmsystem.h>

class TWaveRead
 {
   private:
     HMMIO       IoHandle;              /* file handle for open file */
     MMCKINFO    mmckinfoParent;		/* parent chunk information structure */
     MMCKINFO    mmckinfoSubchunk;	/* subchunk information structure */

   public:
     WAVEFORMATEX WaveFormat; /* WAVEFORMATEX structure for reading in the WAVE fmt chunk */
     int    	 WaveDataSize; /* Size of waveform data */


    TWaveRead();
    ~TWaveRead();
    int OpenFile(char *filename);
    void CloseFile(void);
    short Read(void);
 };

//-------------------------------------------------------
#endif
