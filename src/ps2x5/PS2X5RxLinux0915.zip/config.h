#ifndef _TYPEDEFS_1234567C_INCLUDED
#define _TYPEDEFS_1234567C_INCLUDED
//----------------------------------------------------------------

#include <stdio.h>
      
#define FOR_LINUX 1
#define FOR_ANDROID 0

#define DEBUG_PRINT 0

#define FSK2_5_CRC_MASK 0x357A 
#define FSK2_5_EOT_CRC_MASK 0x53A7 

#define NOMINAL_SAMPLING_RATE 11025
#define NOMINAL_EQ_RATE 11025.0  

#define FINE_SINUS_TABLE_LEN  32768  
#define SINUS_AMPLITUDE 32000        

  
#define SAMPLE_BUF_LEN 2048
        
  
#define EOT_SYM 4

#define ERR_PRINT_FORMAT "{ER=%.1lf%%}\r\n"
       
// Special symbols

#define FSK3_START_SYM  (-21)
#define FSK3_STOP_SYM   (-22)

                  
/* Definition of Types *
 ***********************/


typedef unsigned char u8_t;
typedef unsigned short u16_t;
typedef unsigned long u32_t;


typedef signed char  s8_t;
typedef signed short s16_t;
typedef signed long  s32_t;


#endif


