#!/bin/sh
./decodealsa plughw:1,0 1900 50 50

