#include "config.h"

#include <stdlib.h>
#include <stdio.h>

#if FOR_LINUX
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netdb.h> 
#define closesocket close
#define INVALID_SOCKET  (SOCKET)(~0)
#define SOCKET_ERROR            (-1)
#else
#include <winsock2.h>
#include <mem.h>
#define socklen_t int
#endif
    
#include <string.h>
#include <errno.h>
#include "sockudp.h"



 void Sudp_Create(struct TSockUdp *me)
 {
  me->Error=1;
  me->St=INVALID_SOCKET;
  memset(&me->RecvFromAddr,0,sizeof(me->RecvFromAddr));
 }

 void Sudp_Destroy(struct TSockUdp *me)
 {
  Sudp_Close(me);
 }

//--------------------------------------------------------------
int Sudp_Open(struct TSockUdp *me,char *localhost, char *localport, char *remotehost, char *remoteport)
{
 static char udpstr[]="udp";
 struct sockaddr_in local;
 int rez;
 int tr;

 me->Error=0;
 
 rez= Sudp_SetAddress(me,remotehost, remoteport, &(me->ToAddr), udpstr);
 if(rez) return rez;
 
 rez= Sudp_SetAddress(me,localhost, localport, &local, udpstr);
 if(rez) return rez;

 me->St= socket(AF_INET,SOCK_DGRAM,0);

 if(me->St==INVALID_SOCKET)
  {
   me->Error|=8;
   return 8;
  }

 if(bind(me->St,(struct sockaddr*)&local,sizeof(local)))
  {
   me->Error|=16;
   closesocket(me->St);
   me->St=INVALID_SOCKET;
   return 16;
  }
 tr=0xFFFFFFFF;
 setsockopt(me->St,SOL_SOCKET,SO_BROADCAST,(char*)&tr,sizeof(tr)); // �������� ����������������� ���������

 return 0;
}

//--------------------------------------------------------------
void Sudp_Close(struct TSockUdp *me)
{

 if(me->St == INVALID_SOCKET) return;   

 closesocket (me->St);
 me->St=INVALID_SOCKET;
}

//--------------------------------------------------------------
int Sudp_SetAddress(struct TSockUdp *me,char *hname, char *sname, struct sockaddr_in *sap, char *protocol)
{
 struct servent *sp;
 struct hostent *hp;
 char *endptr;
 short port;

 memset(sap, 0, sizeof(*sap));
 sap->sin_family = AF_INET;

 if(hname!=NULL)                
  {
   if((*hname)!= '\0')
   {
     unsigned long adr=inet_addr(hname);
     if(adr!=INADDR_NONE)
      {
       sap->sin_addr.s_addr=adr;
      }
     else
      {
       hp=gethostbyname(hname);                    
       if(hp==NULL)
        {
         me->Error |= 2;
         return 2;
        }
        sap->sin_addr= *(struct in_addr*)hp->h_addr;
      }
    }
   else sap->sin_addr.s_addr= htonl(INADDR_ANY);
  }
 else
    {
     sap->sin_addr.s_addr= htonl(INADDR_ANY);
    }

 port= strtol(sname, &endptr, 0);
 if(*endptr=='\0')  sap->sin_port=htons(port);
 else
    {
     sp=getservbyname(sname,protocol);
     if(sp==NULL)
      {
       me->Error |= 4;
       return 4;
      }
     sap->sin_port= sp->s_port;
    }

  return 0;
}
//----------------------------------------------------------------
int Sudp_SendTo(struct TSockUdp *me,char *remotehost, char *remoteport, unsigned char *data,int len)
{
 static char udpstr[]="udp";
 int rez;
 rez= Sudp_SetAddress(me,remotehost, remoteport, &(me->ToAddr), udpstr);
 if(rez) return rez;
 rez=Sudp_Send(me,data,len);
 return rez;
}


//---------------------------------------------------------------
int Sudp_Send(struct TSockUdp *me,unsigned char *data,int len)
{
 int rez;
 int fdmax1;


 if(me->St==INVALID_SOCKET) 
  {
   me->Error|=32;
   return 32;
  }
 if(me->Error) return me->Error;

 rez=sendto(me->St,data,len,0,(struct sockaddr*)&(me->ToAddr),sizeof(me->ToAddr));

 if(rez==SOCKET_ERROR) return 64;

 return 0;
}
//------------------------------------------------------------------------------
int Sudp_Receive(struct TSockUdp *me,unsigned char *data,int maxlen, int timeout, int *len)
{
 // timeout - � �������������
 fd_set readfd;
 struct timeval tv;
 int rc; 
 int fdmax1;
 socklen_t fromlen;

 *len=0;

 if(me->St==INVALID_SOCKET) 
  {
   me->Error|=128;
   return 128;
  }
 if(me->Error) return me->Error;


 FD_ZERO(&readfd);
 FD_SET(me->St, &readfd);
 fdmax1=0;
#if FOR_LINUX
 fdmax1=me->St+1;
#endif


 tv.tv_sec=timeout/1000;
 tv.tv_usec=(timeout%1000)*1000;

 
 rc=select(fdmax1,&readfd,NULL,NULL,&tv);
 if(rc==SOCKET_ERROR)
  {
   if(errno==EINTR) return 0; // �������� �������� ��������, ������� �� ����-���
   closesocket(me->St);
   me->St=INVALID_SOCKET;
   me->Error|=256;
   return 256;
  }

 if(!rc) return 0; // ����-���

 if(!FD_ISSET(me->St,&readfd)) return 0; // �� ��� �����, ��������� �� ����-���

 
 fromlen= sizeof(me->FromAddr);
 rc=recvfrom(me->St,data,maxlen,0, (struct sockaddr*)&(me->FromAddr),&fromlen);


 if(rc==SOCKET_ERROR)
  {
   closesocket(me->St);
   me->St=INVALID_SOCKET;
   me->Error|=512;
   return 512;
  }

 *len=rc;

 memcpy(&(me->RecvFromAddr),&(me->FromAddr),sizeof(me->RecvFromAddr));
 return 0;
}
//-----------------------------------------------------------------------

