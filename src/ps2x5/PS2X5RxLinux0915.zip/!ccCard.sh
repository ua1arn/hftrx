#!/bin/sh
g++ decodealsa.cpp fsk2x5rx.cpp rs_code_u.cpp sinustable.cpp crc.cpp filters.cpp fir-par.cpp -lasound -o decodealsa
