//---------------------------------------------------------------------------
// �������� RTP-����� �� ��������� ���������� � ���� , 11025/16 
#include "config.h"
          
#if FOR_LINUX
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <termios.h>
#include <termio.h>
#include <alsa/asoundlib.h>
              
              
#define Sleep(x) usleep(x*1000)
#define O_TEXT 0
#define SH_DENYWR 0
//#define O_BINARY 0

#define strncmpi strncasecmp  
#else

//#include <condefs.h>
//#include <system.hpp>
#include <winsock2.h>
#include <io.h>
#include <share.h>
//#include <process.h>
//#include <conio.h>

#endif

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <signal.h>
#include <sys/timeb.h>


#include "sockudp.h"

//---------------------------------------------------------------------------


int SocketInited=0;
struct TSockUdp  SudpOut;
volatile int UserBreak=0;
//---------------------------------------------------------------------------------------------------------


char LportOut[]="";
char LaddrOut[32]="";

char *RportOut;
char *RaddrOut;

char *SoundDevName;

int  VerboseFlags=0;

int  Rezult=99;

snd_pcm_t *SoundHandle=NULL;


//------------------------------------

#define RTP_LEN 524 /* ����� RTP-������ � ������ - 256 s16be + 12 ���� ��������� */
#define SND_BUFF_LEN (RTP_LEN*2) /* ������ � �������, ����� alsa ������ ������� */
u8_t    SoundBuffer[SND_BUFF_LEN];
snd_pcm_uframes_t SoundFrames;

int SoundDeviceInit(char *devname);
void AddSample(s16_t sample);
void before_exit(void);
void Exit(int level);
void FormCreate(void);
void DoCmd(void);





void signal_handler(int sig)
{
#if FOR_LINUX

	switch(sig)
	{
		case SIGHUP:
			break;
        case SIGTERM:
        case SIGINT:
			 UserBreak=1;
			break;
	}
#endif
}


//------------------------------------

int main(int argc, char *argv[])
{
 int paramsi;

#if FOR_LINUX
  signal(SIGCHLD, SIG_IGN);
  signal(SIGTSTP, SIG_IGN);
  signal(SIGTTOU, SIG_IGN);
  signal(SIGTTIN, SIG_IGN);
  signal(SIGHUP, SIG_IGN); // ������������ ������ � ������� ��� ������ ��� ������������� ������ ������������
  signal(SIGTERM, SIG_IGN);
  signal(SIGINT, signal_handler); 
#else
 SetConsoleCtrlHandler((PHANDLER_ROUTINE)MyHandlerRoutine,TRUE);
 setmode(_fileno(stdin), O_BINARY);
#endif

 atexit(before_exit);

 if((argc!=4) || (argv[1][0]=='-'))
  {
   fprintf(stderr,"\n Usage: \n %s Input_device Remote_IP Remote_PORT \n",argv[0]);
   //fprintf(stderr,"Use '-' for stdin  \n");
   //fprintf(stderr,"Available options: \n");
   //fprintf(stderr,"  -dN  - delay in ms between packets \n");
   //fprintf(stderr,"  -vVerboseFlags - to select debug info \n\n");
   exit(HELP);
  }
 



 Sudp_Create(&SudpOut);

 SoundDevName=argv[1];
 RaddrOut=argv[2];
 RportOut=argv[3];

 Rezult=99;
 
 while(!UserBreak)
  {
   FormCreate();
   DoCmd();
   before_exit();
   if(!UserBreak)
    {
     fprintf(stderr,"\nWait ... \n");
     Sleep(5000);
    }
  }
 Exit(Rezult);

 return Rezult;
}
//---------------------------------------------------------------------------
#define BUFF_LEN 1600
void DoCmd(void)
{
 int rez,i;
 s16_t *p;

 Sudp_Close(&SudpOut);

 rez=Sudp_Open(&SudpOut,LaddrOut,LportOut,RaddrOut,RportOut);


 if(rez) 
  {
   fprintf(stderr,"Open UDP-socket error! (%d) \n",rez);
   return;
  }


 rez=SoundDeviceInit(SoundDevName);
 if(rez) 
  {
   fprintf(stderr,"Sound device open error! (%d) \n",rez);
   return;
  }

 while(!UserBreak)
  {
    rez = snd_pcm_readi(SoundHandle, SoundBuffer, SoundFrames);
    if (rez == -EPIPE) {
      /* EPIPE means overrun */
      fprintf(stderr, "overrun occurred\n");
      snd_pcm_prepare(SoundHandle);
    } 
    else if (rez < 0) {
      fprintf(stderr,"error from read: %s\n",snd_strerror(rez));
      return;
    }
    else if (rez != (int)SoundFrames) {
      fprintf(stderr, "short read, read %d frames\n", rez);
    }


    p= (s16_t*) SoundBuffer;
    for(i=0;i<rez;i++) AddSample(*(p++));

   }          

  
 snd_pcm_drain(SoundHandle);

 if(UserBreak) Rezult=USER_BREAK;
 else Rezult=0;
}
//---------------------------------------------------------------------------
void FormCreate(void)
{
#if FOR_LINUX
 //
#else
 WORD wVersionRequested=2;
 WSADATA wsaData;
 int err;

 /* Confirm that the WinSock DLL supports 2.0.*/
 /* Note that if the DLL supports versions greater    */
 /* than 2.0 in addition to 2.0, it will still return */
 /* 2.0 in wVersion since that is the version we      */
 /* requested.                                        */
  err = WSAStartup( wVersionRequested, &wsaData );
  if (err || LOBYTE( wsaData.wVersion ) != 2 || HIBYTE( wsaData.wVersion ) != 0 )
    {
     if(!err) WSACleanup();
     fprintf(stderr,"WinSock initialization error!\n");
     Exit(SOCKET_OP_ERROR);
    }

#endif

   SocketInited=1;
}
//---------------------------------------------------------------------------
void FileNotOpen(char *filename)
/* �������� ��������� � ��������� ��������� */
 {
      fprintf(stderr,"\n File \"%s\" open error! \n",filename);
      Exit(FILE_ERROR);
 }
//-------------------------------------------------------------------------------------------------
void Exit(int level)
{
 before_exit();
   exit(level);
}
//----------------------------------------------------------------------------------------------------------
void before_exit(void)
{

   Sudp_Close(&SudpOut);
   if(SocketInited)
   {
    SocketInited=0;
#if !FOR_LINUX
     WSACleanup();
#endif
   }

#if FOR_LINUX
   if(SoundHandle!=NULL)
    {
     snd_pcm_close(SoundHandle);
     SoundHandle=NULL;
    }
#endif

}

//-----------------------------------------------------------------------------------------------------------
#if FOR_LINUX
 //
#else 
BOOL MyHandlerRoutine(DWORD tsign)
{
 before_exit();
 return FALSE;
}
#endif
//-------------------------------------------------------------------------------------------------------------
void AddSample(s16_t sample)
{
 int rez;
 static u16_t pkt_counter=0;
 static u32_t time_mark=0;
 static u8_t RtpBuffer[RTP_LEN+4];
 static int RtpBuffIndex=12; // ������ ����. ��������� == 12 ����
 static int first_start=1;
 time_t gmt;
 static u32_t  timeu;
 u32_t timeu1;


 if(first_start)
  {
   first_start=0;

   time(&gmt);
   timeu= gmt;
   fprintf(stderr,"Unix time: 0x%08X \n",timeu);
   if(timeu > 0x58A2095B) timeu1=timeu-0x58A2095B;
   else timeu1=timeu&0xFFFFFF;

   pkt_counter= (double)timeu1 * (11025.0/(double)((RTP_LEN-12)/2));
   time_mark= (double)timeu1 * 11025.0;

  }


 RtpBuffer[RtpBuffIndex++]= (sample>>8)&255; // BE
 RtpBuffer[RtpBuffIndex++]= sample&255; // BE

 if(RtpBuffIndex<RTP_LEN) return;

 // ��������� ������ �����

 RtpBuffIndex=12;

 pkt_counter++;
 time_mark+=((RTP_LEN-12)/2);

 RtpBuffer[0]=0x80;
 RtpBuffer[1]=0x61;


 RtpBuffer[2]=(pkt_counter>>8)&255;
 RtpBuffer[3]=pkt_counter&255;


 RtpBuffer[4]=(time_mark>>24)&255;
 RtpBuffer[5]=(time_mark>>16)&255;
 RtpBuffer[6]=(time_mark>>8)&255;
 RtpBuffer[7]= time_mark&255;


 RtpBuffer[8]=(timeu>>24)&255;
 RtpBuffer[9]=(timeu>>16)&255;
 RtpBuffer[10]=(timeu>>8)&255;
 RtpBuffer[11]= timeu&255;

 //RtpBuffer[8]= 0;
 //RtpBuffer[9]= 0;
 //RtpBuffer[10]= 0;
 //RtpBuffer[11]= 1;

 rez=Sudp_SendTo(&SudpOut,RaddrOut, RportOut, RtpBuffer, RTP_LEN);
 if(rez) 
       {
        fprintf(stderr,"\n Udp sending error to %s:%s (%d) \n",RaddrOut,RportOut,rez);
       }

}
//----------------------------------------------------------
int SoundDeviceInit(char *devname)
// ���������� 0 ��� ������
{

 int rc;
 snd_pcm_hw_params_t *params;
 unsigned int val;
 snd_pcm_uframes_t frames;


 /* Open PCM device for recording (capture). */
 rc = snd_pcm_open(&SoundHandle, devname , SND_PCM_STREAM_CAPTURE, 0);
 if (rc < 0)
   {
    fprintf(stderr,"Unable to open pcm device: %s\n",snd_strerror(rc));
    SoundHandle=NULL;
    return -1;
 }


 /* Allocate a hardware parameters object. */
 snd_pcm_hw_params_alloca(&params);


 /* Fill it in with default values. */
 snd_pcm_hw_params_any(SoundHandle, params);


 /* Set the desired hardware parameters. */


 /* Interleaved mode */
 int err=snd_pcm_hw_params_set_access(SoundHandle, params,SND_PCM_ACCESS_RW_INTERLEAVED);
 if (err < 0) fprintf(stderr,"Access type not available\n");                      


 /* Signed 16-bit little-endian format */
 err=snd_pcm_hw_params_set_format(SoundHandle, params,SND_PCM_FORMAT_S16_LE);                                 
if (err < 0) fprintf(stderr,"PCM format not available\n");                      

 /* mono */
 err=snd_pcm_hw_params_set_channels(SoundHandle, params, 1);                                 
 if (err < 0) fprintf(stderr,"Channel num not available\n");                      



 /* 11025 samples/second sampling rate */
 val = 11025;                                                     
 err=snd_pcm_hw_params_set_rate_near(SoundHandle, params,&val, 0);
 if (err < 0) fprintf(stderr,"Rate not available\n");                      

  if ((float)val * 1.05 < 11025.0 || (float)val * 0.95 > 11025.0)
    {
	 fprintf(stderr,"Warning: rate is not accurate (requested = 11025 , got = %d )\n", val);
   }


 /* Set period size to n frames. */
 frames = (RTP_LEN-12)/2;
 snd_pcm_hw_params_set_period_size_near(SoundHandle,params, &frames, 0);

 /* Write the parameters to the driver */
 rc = snd_pcm_hw_params(SoundHandle, params);
 if (rc < 0) 
   {
    fprintf(stderr,"unable to set hw parameters: %s\n",snd_strerror(rc));
    return -2;
   }


 /* Use a buffer large enough to hold one period */
 snd_pcm_hw_params_get_period_size(params,&frames, 0);
 fprintf(stderr,"Perion size: %d frames \n",frames);                                      

 if((frames*2)>SND_BUFF_LEN)
  {
   fprintf(stderr,"Unsufficient buffer size!\n");
   return -3;
  }

 SoundFrames=frames;

 return 0;
}
