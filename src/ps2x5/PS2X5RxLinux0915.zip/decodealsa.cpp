
#include "config.h"
          

#if FOR_LINUX
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
//#include <netinet/in.h>
//#include <sys/socket.h>
#include <termios.h>
#include <termio.h>
#include <alsa/asoundlib.h>
             
             
#define Sleep(x) usleep(x*1000)
#define O_TEXT 0
#define SH_DENYWR 0
//#define O_BINARY 0

#define strncmpi strncasecmp  
#else

//#include <condefs.h>
//#include <system.hpp>
#include <winsock2.h>
#include <io.h>
#include <share.h>
//#include <process.h>
//#include <conio.h>

#endif

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <signal.h>
#include <sys/timeb.h>
       
       
#include "config.h"
#include "fsk2x5rx.h"
#include "rs_code_u.h"


TFsk2x5Decoder FskRx;


#define HELP 1
#define SOUND_CARD_ERROR 9
#define USER_BREAK 10

#define ERROR_BREAK 100


void RxPutSym(char sym);
void before_exit(void);
void Exit(int level);
void DoCmd(void);
int SoundDeviceInit(char *devname);

//---------------------------------------------------------------------------

#define SND_BUFF_LEN 4096 
u8_t    SoundBuffer[SND_BUFF_LEN];
snd_pcm_uframes_t SoundFrames;


int FilledBuffs=0; // ���������� ����������� �������
int AddedBuffs=0;  // ���������� �������������� ��� ���������� �������
int WaveHead=0;    // ����� ������, � ������� ���� ������
int WaveTail=0;    // ����� ������, �� �������� ���� ������


volatile int UserBreak=0;
volatile int ErrorBreak=0;

char HfpOutputDir[128]="./";
//---------------------------------------------------------------------------------------------------------




int  VerboseFlags=0;

int MaxInput=0;
int  Rezult=99;


double FskCenterFreq= 1700.0; // center freq
double FskSpeed= 50.0; 
double FskShift= 50.0; 

char *SoundDevName= NULL;
snd_pcm_t *SoundHandle=NULL;

//------------------------------------


void signal_handler(int sig)
{
#if FOR_LINUX

    switch(sig)
    {
        case SIGHUP:
            break;
        case SIGTERM:
        case SIGINT:
             UserBreak=1;
            break;
    }
#endif
}


int main(int argc, char *argv[])
{
 int paramsi;

#if FOR_LINUX
  signal(SIGCHLD, SIG_IGN);
  signal(SIGTSTP, SIG_IGN);
  signal(SIGTTOU, SIG_IGN);
  signal(SIGTTIN, SIG_IGN);
  signal(SIGHUP, signal_handler); // ������������ ������ � ������� ��� ������ ��� ������������� ������ ������������
  signal(SIGTERM, signal_handler);
  signal(SIGINT, signal_handler); 
#else
 SetConsoleCtrlHandler((PHANDLER_ROUTINE)MyHandlerRoutine,TRUE);
 //setmode(_fileno(stdin), O_BINARY);
#endif

 atexit(before_exit);

 if(argc<2) 
  {
   fprintf(stderr," Usage: \n %s Sound_device [center freq] [speed] [shift] \n",argv[0]);
   //ShowCardList();
   exit(HELP);
  }
 

 SoundDevName=argv[1];


 if(argc>2)
  {
   int cfreq=atoi(argv[2]);
   FskCenterFreq= (double)cfreq;
  }


 if(argc>3)
  {
   int speed=atoi(argv[3]);
   FskSpeed= (double)speed;
  }


 if(argc>4)
  {
   int shift=atoi(argv[4]);
   FskShift= (double)shift;
  }


 printf("\nSound device: %s \n",SoundDevName);
 printf("\nCenter freq: %.2lf \n",FskCenterFreq);
 printf("\nSpeed: %.2lf \n",FskSpeed);
 printf("\nShift: %.2lf \n",FskShift);



 Rezult=99;

  DoCmd();

  Exit(Rezult);

 return Rezult;
}
//---------------------------------------------------------------------------
void DoCmd(void)
{
 FskRx.Init();
 FskRx.Reset(FskSpeed,0);
 FskRx.SetFreqAndShift(FskCenterFreq,FskShift);
 //FskRx.SetCallback(&OnMessageHandler);


 int rez=SoundDeviceInit(SoundDevName);
 if(rez) 
  {
   fprintf(stderr,"Sound device open error! (%d) \n",rez);
   Rezult=SOUND_CARD_ERROR;
   return;
  }


 while ((!UserBreak) && (!ErrorBreak))
  {
    rez = snd_pcm_readi(SoundHandle, SoundBuffer, SoundFrames);
    if (rez == -EPIPE) {
      /* EPIPE means overrun */
      fprintf(stderr, "overrun occurred\n");
      snd_pcm_prepare(SoundHandle);
    } 
    else if (rez < 0) {
      fprintf(stderr,"error from read: %s\n",snd_strerror(rez));
      ErrorBreak=1;
      break;
    }
    else if (rez != (int)SoundFrames) {
      fprintf(stderr, "short read, read %d frames\n", rez);
    }


    s16_t *p= (s16_t*) SoundBuffer;
    for(int i=0;i<rez;i++) FskRx.RxSample(*(p++));
   }          

  
 snd_pcm_drain(SoundHandle);


 if(UserBreak) Rezult=USER_BREAK;
 else Rezult=ERROR_BREAK;
}
//---------------------------------------------------------------------------
void Exit(int level)
{
 before_exit();
 exit(level);
}
//----------------------------------------------------------------------------------------------------------
void before_exit(void)
{
#if FOR_LINUX
   if(SoundHandle!=NULL)
    {
     snd_pcm_close(SoundHandle);
     SoundHandle=NULL;
    }
#endif
}
//-----------------------------------------------------------------------------------------------------------

int SoundDeviceInit(char *devname)
// ���������� 0 ��� ������
{

 int rc;
 snd_pcm_hw_params_t *params;
 unsigned int val;
 snd_pcm_uframes_t frames;


 /* Open PCM device for recording (capture). */
 rc = snd_pcm_open(&SoundHandle, devname , SND_PCM_STREAM_CAPTURE, 0);
 if (rc < 0)
   {
    fprintf(stderr,"Unable to open pcm device: %s\n",snd_strerror(rc));
    SoundHandle=NULL;
    return -1;
 }


 /* Allocate a hardware parameters object. */
 snd_pcm_hw_params_alloca(&params);


 /* Fill it in with default values. */
 snd_pcm_hw_params_any(SoundHandle, params);


 /* Set the desired hardware parameters. */


 /* Interleaved mode */
 int err=snd_pcm_hw_params_set_access(SoundHandle, params,SND_PCM_ACCESS_RW_INTERLEAVED);
 if (err < 0) fprintf(stderr,"Access type not available\n");                      


 /* Signed 16-bit little-endian format */
 err=snd_pcm_hw_params_set_format(SoundHandle, params,SND_PCM_FORMAT_S16_LE);                                 
if (err < 0) fprintf(stderr,"PCM format not available\n");                      

 /* mono */
 err=snd_pcm_hw_params_set_channels(SoundHandle, params, 1);                                 
 if (err < 0) fprintf(stderr,"Channel num not available\n");                      



 /* 11025 samples/second sampling rate */
 val = 11025;                                                     
 err=snd_pcm_hw_params_set_rate_near(SoundHandle, params,&val, 0);
 if (err < 0) fprintf(stderr,"Rate not available\n");                      

  if ((float)val * 1.05 < 11025.0 || (float)val * 0.95 > 11025.0)
    {
     fprintf(stderr,"Warning: rate is not accurate (requested = 11025 , got = %d )\n", val);
   }


 /* Set period size to n frames. */
 frames = (SND_BUFF_LEN)/2;
 snd_pcm_hw_params_set_period_size_near(SoundHandle,params, &frames, 0);

 /* Write the parameters to the driver */
 rc = snd_pcm_hw_params(SoundHandle, params);
 if (rc < 0) 
   {
    fprintf(stderr,"unable to set hw parameters: %s\n",snd_strerror(rc));
    return -2;
   }


 /* Use a buffer large enough to hold one period */
 snd_pcm_hw_params_get_period_size(params,&frames, 0);
 fprintf(stderr,"Period size: %d frames \n",frames);                                      

 if((frames*2)>SND_BUFF_LEN)
  {
   fprintf(stderr,"Unsufficient buffer size!\n");
   return -3;
  }

 SoundFrames=frames;

 return 0;
}
//--------------------------------------------------
void RxPutSym(char sym)
{
 char sym1=sym;
 if(((sym&255)<' ') && (sym!='\r') && (sym!='\n')) sym1='.';
 putchar(sym1);
}
//---------------------------------------------------------------------------
void RxBufClear(void)
{
 // ���������� � ������ ����� ��������� 
 RxPutSym('\r');
 RxPutSym('\n');
 fflush(stdout);
}
//-----------------------------------------------------------------------------
void RxPutString(char *str)
{
 for(;*str;str++) RxPutSym(*str);
 fflush(stdout);
}
//-----------------------------------------------------------------------------
void RxPutBlock(u8_t *buffer, int eot_pos)
{
 int len=7;
 if(eot_pos>=0) len=eot_pos;
 for(int i=0;i<len;i++)
  {
   RxPutSym(buffer[i]);
  }
 fflush(stdout);
}
//-----------------------------------------------------------------------------

