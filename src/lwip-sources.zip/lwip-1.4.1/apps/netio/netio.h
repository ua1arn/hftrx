#ifndef __NETIO_H__
#define __NETIO_H__

void netio_init(void);

#endif /* __NETIO_H__ */
