#include <string.h>
#include <math.h>

#include "hardware.h"
#include "formats.h"
#include "src/display/display.h"

#include "T113-s3/g2d.h"

#include "LuPng/lupng.h"

//PNG-�����
#include "Back0.png.h"
#include "Bubble.png.h"
#include "Cobra.png.h"

LuImage *png[3];                                     //������ ���������� �� ������ PNG (����� PNG)

void PNG_Load(LuImage **png,const unsigned char *buffer)      //��������� PNG �� buffer � ����� ���������� ������(malloc)
{
 *png=luPngReadMemory((char*)buffer);
}

void PNG_Free(LuImage *png)                          //����������� ������ ��������� PNG
{
 if(png)luImageRelease(png,NULL);
}

//�������� ��������� ----------------------------------------------------------------------------------------------------------
//
//void PNG_Background(LuImage *png,uint8_t layer)           //������� ������� PNG �� �������
//{
// if(png)MEMCPY((uint8_t*)(layer?VIDEO_MEMORY1:VIDEO_MEMORY0),png->data,png->dataSize);
//}
//
//void PNG_Draw(uint32_t px,uint32_t py,LuImage *png,uint8_t layer)   //������� PNG �� ������� � �������� �����������
//{
// if(png==NULL)return;
//
// uint32_t line=png->width<<2;
//
// uint32_t * __restrict__ src=(uint32_t*)png->data;
// uint32_t * __restrict__ dst=(uint32_t*)(layer?VIDEO_MEMORY1:VIDEO_MEMORY0);
//
// dst+=(LCD_PIXEL_WIDTH*py)+px;
//
// for(uint32_t y=0;y<png->height;y++)
// {
//  memcpy(dst,src,line);
//  dst+=LCD_PIXEL_WIDTH;
//  src+=png->width;
// }
//}

//G2D ��������� ----------------------------------------------------------------------------------------------------------

static g2d_fillrect G2D_FILLRECT;
static g2d_blt      G2D_BLT;

void G2D_PNG_Draw(uint32_t px,uint32_t py,LuImage *png,uint8_t layer,uint8_t a) //������� PNG �� ������� � �������� ����������� � ������� PNG
{
	 if(png==NULL)return;

	 if(a)G2D_BLT.flag=G2D_FIL_PLANE_ALPHA; //|G2D_BLT_SRC_PREMULTIPLY
	 else G2D_BLT.flag=G2D_FIL_PIXEL_ALPHA; //|G2D_BLT_SRC_PREMULTIPLY

	 G2D_BLT.src_image.addr[0]=(uintptr_t)png->data;       //память, где хранится картинка
	 G2D_BLT.src_image.addr[0]=(uintptr_t)png->data;
	 G2D_BLT.src_image.addr[0]=(uintptr_t)png->data;

	 G2D_BLT.src_image.w=png->width;                 //габариты атласа
	 G2D_BLT.src_image.h=png->height;

	 G2D_BLT.src_image.format=G2D_FMT_ABGR_AVUY8888;
	 G2D_BLT.src_image.pixel_seq=G2D_SEQ_NORMAL;

	 G2D_BLT.src_rect.x=0;                           //смещение в атласе
	 G2D_BLT.src_rect.y=0;

	 G2D_BLT.src_rect.w=png->width;                  //размер
	 G2D_BLT.src_rect.h=png->height;

	 G2D_BLT.dst_image.addr[0]=layer?VIDEO_MEMORY1:VIDEO_MEMORY0;
	 G2D_BLT.dst_image.addr[0]=layer?VIDEO_MEMORY1:VIDEO_MEMORY0;
	 G2D_BLT.dst_image.addr[0]=layer?VIDEO_MEMORY1:VIDEO_MEMORY0;

	 G2D_BLT.dst_image.w=LCD_PIXEL_WIDTH;
	 G2D_BLT.dst_image.h=LCD_PIXEL_HEIGHT;

	 G2D_BLT.dst_image.format=G2D_FMT_ARGB_AYUV8888;
	 G2D_BLT.dst_image.pixel_seq=G2D_SEQ_NORMAL;

	 G2D_BLT.dst_x=px;                                 //координаты вывода
	 G2D_BLT.dst_y=py;

	 G2D_BLT.color=0x00000000;                         //цветовой ключ RGB
	 G2D_BLT.alpha=a;                                  //альфа плоскости

	 g2d_blit(&G2D_BLT);
}

void Rectangle(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint32_t c,uint8_t layer)
{
	 G2D_FILLRECT.flag=G2D_BLT_NONE;

	 //Параметры приёмной плоскости
	 G2D_FILLRECT.dst_image.addr[0]=layer?VIDEO_MEMORY1:VIDEO_MEMORY0;;
	 G2D_FILLRECT.dst_image.addr[1]=layer?VIDEO_MEMORY1:VIDEO_MEMORY0;;
	 G2D_FILLRECT.dst_image.addr[2]=layer?VIDEO_MEMORY1:VIDEO_MEMORY0;;

	 G2D_FILLRECT.dst_image.w=LCD_PIXEL_WIDTH;
	 G2D_FILLRECT.dst_image.h=LCD_PIXEL_HEIGHT;

	 G2D_FILLRECT.dst_image.format=G2D_FMT_ARGB_AYUV8888;
	 G2D_FILLRECT.dst_image.pixel_seq=G2D_SEQ_NORMAL;

	 G2D_FILLRECT.dst_rect.x=x;          //координаты прямоугольника
	 G2D_FILLRECT.dst_rect.y=y;

	 G2D_FILLRECT.dst_rect.w=w;          //размеры прямоугольника
	 G2D_FILLRECT.dst_rect.h=h;

	 G2D_FILLRECT.color=c;               //цвет прямоугольника ARGB
	 G2D_FILLRECT.alpha=0;               //альфа прямоугольника (с точностью наоборот 0 - прямоугольник глухой, 0xFF - прозрачный)

	 g2d_fill(&G2D_FILLRECT);
}

ALIGNX_BEGIN PACKEDCOLORMAIN_T tfb0 [GXSIZE(DIM_X, DIM_Y)] ALIGNX_END;
ALIGNX_BEGIN PACKEDCOLORMAIN_T tfb1 [GXSIZE(DIM_X, DIM_Y)] ALIGNX_END;

void g2d_main_layers_alpha(void)
{

 //���������� PNG
 PNG_Load(&png[0],Back0_png);
 PNG_Load(&png[1],Bubble_png);
 PNG_Load(&png[2],Cobra_png);

 arm_hardware_ltdc_main_set_no_vsync4(VIDEO_MEMORY0, VIDEO_MEMORY1, (uintptr_t) 0, (uintptr_t) 0);


 //VSync();                                       //для плавности движения (для ликвидации эффектов тиринга и статтеринга)

 G2D_PNG_Draw(0,0,png[0],0,0);                  //выводим PNG в плоскость 0 (низкий приоритет, без пиксельной альфы)

 G2D_PNG_Draw(  0,  0,png[1],1,0   );           //выводим PNG в плоскость 1 (высокий приоритет, с пиксельной альфой)
 G2D_PNG_Draw(256,  0,png[1],1,0   );           //выводим PNG в плоскость 1 (высокий приоритет, с пиксельной альфой)
 G2D_PNG_Draw(256, 64,png[1],1,0   );           //выводим PNG в плоскость 1 (высокий приоритет, с пиксельной альфой)

 G2D_PNG_Draw(  0,256,png[1],1,0x7F);           //выводим PNG в плоскость 1 (высокий приоритет, с пиксельной альфой)

 G2D_PNG_Draw(512,  0,png[2],1,0);              //выводим PNG в плоскость 1 (высокий приоритет, с пиксельной альфой)

 Rectangle(250,350,200,150,0xFFFFFFFF,1);       //прямоугольник с альфой 0xFF 255 100%
 Rectangle(470,350,200,150,0x7FFFFFFF,1);       //прямоугольник с альфой 0x7F 127 50%

 while(1)
	 ;

 //!!! если какие-то PNG более не нужны, то нужно освобождать память
 PNG_Free(png[0]);
 PNG_Free(png[1]);
 PNG_Free(png[2]);
}
